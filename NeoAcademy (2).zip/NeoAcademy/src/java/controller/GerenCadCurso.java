/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Administrador;
import model.Curso;
import model.CursoDAO;
import model.Transacao;

/**
 *
 * @author Victor
 */
@WebServlet(name = "GerenCadCurso", urlPatterns = {"/geren_cad_curso.do"})
public class GerenCadCurso extends HttpServlet {

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String nome = request.getParameter("nome");
        String scargaHoraria = request.getParameter("cargaHoraria");
        String svalor = request.getParameter("valor");
        String idCurso = request.getParameter("idCurso");
        String sidAdmin = request.getParameter("idAdmin");
        String descricao = request.getParameter("descricao");
        
        PrintWriter out = response.getWriter();
        
        String mensagem = "";
        
        Curso c = new Curso();
        
        try{
            if(!idCurso.isEmpty()){
               c.setIdCurso(Integer.parseInt(idCurso));
           }
            if(nome.equals("") || nome.isEmpty() ||
               scargaHoraria.equals("") || scargaHoraria.isEmpty() ||
               svalor.equals("") || svalor.isEmpty() ||
               idCurso.equals("") || idCurso.isEmpty() ||
               sidAdmin.equals("") || sidAdmin.isEmpty() ||
               descricao.equals("") || descricao.isEmpty()){
               mensagem = "Por favor preencha todos os campos";
            }
            int cargaHoraria = Integer.parseInt(scargaHoraria);
            double valor = Double.parseDouble(svalor);
            int idAdmin = Integer.parseInt(sidAdmin);
            c.setNome(nome);
            c.setDescricao(descricao);
            c.setCargaHoraria(cargaHoraria);
            c.setValor(valor);
            Administrador a = new Administrador();
            a.setIdAdmin(idAdmin);
            c.setAdministrador(a);
            CursoDAO cDAO = new CursoDAO();
            if(cDAO.gravarCurso(c)){
                mensagem = "Gravado com sucesso";
            }else{
                mensagem = "Erro ao gravar no banco de dados";
            }  
        }catch(Exception e){
            out.print(e);
            mensagem = "Erro ao executar";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='admin.jsp';");
        out.println("</script>");  
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
