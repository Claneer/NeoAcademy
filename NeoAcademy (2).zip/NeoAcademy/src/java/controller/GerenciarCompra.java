/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Aluno;
import model.Cartao;
import model.CartaoDAO;
import model.Curso;
import model.Matricula;
import model.MatriculaDAO;
import model.Transacao;
import model.TransacaoDAO;
import model.Turma;
import model.TurmaDAO;

/**
 *
 * @author Victor
 */
@WebServlet(name = "GerenciarCompra", urlPatterns = {"/gerenciar_compra.do"})
public class GerenciarCompra extends HttpServlet {


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String idCurso = request.getParameter("idCurso");
        String idAluno = request.getParameter("idAluno");
        String preco = request.getParameter("preco");
        
        RequestDispatcher disp = getServletContext().getRequestDispatcher("/alunoPagamento.jsp");
        request.setAttribute("idCurso", idCurso);
        request.setAttribute("idAluno", idAluno);
        request.setAttribute("preco", preco);
        disp.forward(request, response);
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter out = response.getWriter();
        
        String idCartao = request.getParameter("idCartao");
        String numero = request.getParameter("numero");
        String vencimento = request.getParameter("vencimento");
        String titular = request.getParameter("titular");
        String cvvs = request.getParameter("cvv");
        String idAluno = request.getParameter("idAluno");
        String idCurso = request.getParameter("idCurso");
        String spreco = request.getParameter("preco");
       
        
        String mensagem = "";
        
        Cartao ca = new Cartao();

        try{
            if(!idCartao.isEmpty()){
               ca.setIdCartao(Integer.parseInt(idCartao));
            }
            if(numero.equals("") || numero.isEmpty() ||
              vencimento.equals("") || vencimento.isEmpty() ||
              titular.equals("") || titular.isEmpty() ||
              cvvs.equals("") || cvvs.isEmpty()){
                    mensagem="Preencha os campos";
            }
            if (numero != null && numero.matches("\\d+")) {
                     CartaoDAO cDAO = new CartaoDAO();
            if (cDAO.isValidLuhn(numero)){
                    ca.setNumero(numero);
            }else{
                    mensagem = "Cartão inválido!";
            }
            }else{
                    mensagem = "Cartão nulo ou contendo caracteres especiais";
            }
            int tidCurso = Integer.parseInt(idCurso);
            TurmaDAO turmaDAO = new TurmaDAO();
            int contaTurmas = turmaDAO.virificarTurmaDisponivel(tidCurso);
            if(contaTurmas == 0){
                mensagem = "Não há turmas disponíveis";
                out.println("<script type='text/javascript'>");
                out.println("alert('"+mensagem+"');");
                out.println("location.href='aluno.jsp';");
                out.println("</script>");
                return;
            }
            int midAluno = Integer.parseInt(idAluno);
            MatriculaDAO matriculaDAO = new MatriculaDAO();
            int contaCurso = matriculaDAO.checarMatricula(midAluno, tidCurso);
            if(contaCurso > 0){
                mensagem = "Você já possui este curso";
                out.println("<script type='text/javascript'>");
                out.println("alert('"+mensagem+"');");
                out.println("location.href='alunoMeusCursos.jsp';");
                out.println("</script>");
                return;
            }
            boolean vagasDisponiveis = false;
            List<Turma> listaT = turmaDAO.getListaDeTurmas(tidCurso);
                for(Turma turma : listaT){
                    int idTurma = turma.getIdTurma();
                    int vagas = turma.getNumeroVagas();
                    MatriculaDAO matDAO = new MatriculaDAO();
                    int contarMatriculas = matDAO.contarMatriculas(idTurma);
                    if(contarMatriculas < vagas){
                        vagasDisponiveis = true;
                        break;
                    }
                }
            if(!vagasDisponiveis){
                mensagem = "Não há vagas disponíveis nas turmas";
                out.println("<script type='text/javascript'>");
                out.println("alert('"+mensagem+"');");
                out.println("location.href='aluno.jsp';");
                out.println("</script>");
                return;
            }
            CartaoDAO cartaoDAO = new CartaoDAO();
            int verificaCartao = cartaoDAO.verificaCartao(numero);
            if(verificaCartao > 0){
                int verificaStatusCartao = cartaoDAO.verificaStatusCartao(numero);
                if(verificaStatusCartao == 0){
                    mensagem = "O cartão está desativado";
                    out.println("<script type='text/javascript'>");
                    out.println("alert('"+mensagem+"');");
                    out.println("location.href='alunoComprarCursos.jsp';");
                    out.println("</script>");
                    return;
                }
            }
            ca.setVencimento(vencimento);
            ca.setTitular(titular);
            int cvv = Integer.parseInt(cvvs);
            ca.setCvv(cvv);
            Aluno a = new Aluno();
            a.setIdAluno(Integer.parseInt(idAluno));
            ca.setAluno(a);
            CartaoDAO caDAO = new CartaoDAO();
            if(caDAO.gravarCartao(ca, numero)){
//                mensagem = "Cartão gravado com sucesso";
                Transacao t = new Transacao();
                
                LocalDateTime now = LocalDateTime.now();
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                String dataCadastro = now.format(formatter); 
                t.setData(dataCadastro);
                
                double preco = Double.parseDouble(spreco);
                t.setValor(preco);
                
                t.setNumero(numero);
                
                Aluno al = new Aluno();
                al.setIdAluno(Integer.parseInt(idAluno));
                t.setAluno(al);
                
                Curso cur = new Curso();
                cur.setIdCurso(Integer.parseInt(idCurso));
                t.setCurso(cur);
                
                TransacaoDAO tDAO = new TransacaoDAO();
                if(tDAO.gravarTransacao(t)){
//                    mensagem = "Transação realizada com sucesso";
                    MatriculaDAO mDAO = new MatriculaDAO();
                    Matricula m = new Matricula();
                    
                    int sidAluno = Integer.parseInt(idAluno);
                    Aluno alu = new Aluno();
                    alu.setIdAluno(sidAluno);
                    m.setAluno(alu);
                    
                    int sidCurso = Integer.parseInt(idCurso);
                    
                    TurmaDAO tuDAO = new TurmaDAO();
                    List<Turma> lista = tuDAO.getListaDeTurmas(sidCurso);
                    for (Turma tu : lista) {
                        int idTurma = tu.getIdTurma();
                        int vagas = tu.getNumeroVagas();
                                m.setTurma(tu);
                        int contaMatricula = mDAO.contarMatriculas(idTurma);
                        if(contaMatricula < vagas){
                            if(mDAO.gravarMatricula(m)){
                            mensagem = "Compra realizada com sucesso";
                            break;
                        }else{
                            mensagem = "ERRO";
                        }
                        }else{
                            mensagem = "Erro ao matricular";
                        }
                    }
                }else{
                    mensagem = "Erro ao gerar a transação";
                }
            }else{mensagem="Erro ao gravar o cartão";
            
            }
        }catch(Exception e){
            out.print(e);
            mensagem ="Erro ao executar";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='aluno.jsp';");//informar o local para ser redirecionado
        out.println("</script>");  
        }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
