/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Administrador;
import model.AdministradorDAO;
import model.UsuarioDAO;

/**
 *
 * @author Victor
 */
@WebServlet(name = "GerenCadaAdmin", urlPatterns = {"/geren_cad_administrador.do"})
public class GerenCadAdmin extends HttpServlet {


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter out = response.getWriter();        
        String idAdministrador = request.getParameter("idAdministrador");
        String nome = request.getParameter("nome");
        String email = request.getParameter("email");
        String cpf = request.getParameter("cpf");
        String telefone = request.getParameter("telefone");
        String data_nasc = request.getParameter("data_nasc");
        String cep = request.getParameter("cep");
        String logradouro = request.getParameter("logradouro");
        String bairro = request.getParameter("bairro");
        String cidade = request.getParameter("cidade");
        String uf = request.getParameter("uf");
        String numeroString = request.getParameter("numero");
        String genero = request.getParameter("genero");
        String usuario = request.getParameter("usuario");
        String senha = request.getParameter("senha");
        String confirmarsenha = request.getParameter("confirmarsenha");
        String salarioString = request.getParameter("salario");
        String regex = "\\d{10,11}";
        
        String mensagem = "";
        
        Administrador a = new Administrador();
        boolean valido = false;
      
        
        try{
           if(!idAdministrador.isEmpty()){
               a.setIdAdmin(Integer.parseInt(idAdministrador));
           }
           
           if(nome.equals("") || nome.isEmpty() ||
              email.equals("") || email.isEmpty() ||
              cpf.equals("") || cpf.isEmpty() ||
              telefone.equals("") || telefone.isEmpty() ||
              data_nasc.equals("") || data_nasc.isEmpty() ||
              cep.equals("") || cep.isEmpty() ||
              logradouro.equals("") || logradouro.isEmpty() ||
              bairro.equals("") || bairro.isEmpty() ||
              cidade.equals("") || cidade.isEmpty() ||
              uf.equals("") || uf.isEmpty() ||
              numeroString.equals("") || numeroString.isEmpty() ||
              usuario.equals("") || usuario.isEmpty() ||
              senha.equals("") || senha.isEmpty() ||
              confirmarsenha.equals("") || confirmarsenha.isEmpty() ||
              salarioString.equals("") || salarioString.isEmpty()){
            }else{
                UsuarioDAO uDAO = new UsuarioDAO();
                if (cpf != null && cpf.matches("\\d{11}")){
                    valido = uDAO.validaCPF(cpf);
                }
                if (valido){
                    a.setCpf(cpf);
                }else{
                    mensagem = "CPF inválido";
                    out.println("<script type='text/javascript'>");
                    out.println("alert('"+mensagem+"');");
                    out.println("location.href='cadastraAluno.jsp';");
                    out.println("</script>");
                }
                if (telefone.matches(regex)){
                    a.setTelefone(telefone);
                }else{
                    mensagem = "Número de telefone inválido";
                    out.println("<script type='text/javascript'>");
                    out.println("alert('"+mensagem+"');");
                    out.println("location.href='cadastraAluno.jsp';");
                    out.println("</script>");
                }
              if(!senha.equals(confirmarsenha)){
                 mensagem = "As senhas são diferentes";
              }
              double salario = Double.parseDouble(salarioString);
              int numero = Integer.parseInt(numeroString);
              a.setNome(nome);
              a.setEmail(email);
              a.setData_nasc(data_nasc);
              a.setGenero(genero);
              a.setCep(cep);
              a.setLogradouro(logradouro);
              a.setBairro(bairro);
              a.setCidade(cidade);
              a.setUf(uf);
              a.setNumero(numero);
              a.setUsuario(usuario);
              String senhaCripto = uDAO.hashSenhaMD5(senha);
              a.setSenha(senhaCripto);
              a.setSalario(salario);
              AdministradorDAO aDAO = new AdministradorDAO();
              if (aDAO.gravarAdministrador(a)) {
              mensagem = "Gravado com sucesso";
              }else{
              mensagem = "Erro ao gravar no banco de dados";
              }
        }  
        }catch(Exception e){
            out.print(e);
            mensagem = "Erro ao executar";
        }   
        
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='admin.jsp';");
        out.println("</script>");        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
