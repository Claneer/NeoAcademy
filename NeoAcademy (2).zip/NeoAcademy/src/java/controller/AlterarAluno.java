/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import model.Aluno;
import model.AlunoDAO;
import model.UsuarioDAO;

/**
 *
 * @author Victor
 */
@WebServlet(name = "AlterarAluno", urlPatterns = {"/alterar_aluno.do"})
@MultipartConfig
public class AlterarAluno extends HttpServlet {

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        PrintWriter out = response.getWriter();
        String mensagem = "";
        
        String acao = request.getParameter("acao");
        String idAluno = request.getParameter("idAluno");
        
        Aluno a = new Aluno();
        
        try{
            AlunoDAO aDAO = new AlunoDAO();
            if(acao.equals("alterar")){
                a = aDAO.getCarregaAlunoID(Integer.parseInt(idAluno));
                if(a.getIdAluno()>0){
                RequestDispatcher disp = getServletContext().getRequestDispatcher("/adminAlteraAluno.jsp");
                request.setAttribute("id", a);
                disp.forward(request, response);
            }else{
                mensagem = "Perfil não encontrado";
            }   
            }
            if(acao.equals("deletar")){
                a.setIdAluno(Integer.parseInt(idAluno));
                if(aDAO.Deletar(a)){
                    mensagem = "Deletado com sucesso";
                }else{
                    mensagem = "Erro ao excluir";
                }
            }
            if(acao.equals("ativar")){
                int sidAluno = Integer.parseInt(idAluno);
                if(aDAO.Ativar(sidAluno)){
                    mensagem = "Ativado com sucesso";
                }else{
                    mensagem = "Erro ao ativar";
                }
            }
            if(acao.equals("desativar")){
                int sidAluno = Integer.parseInt(idAluno);
                if(aDAO.Desativar(sidAluno)){
                    mensagem = "Desativado com sucesso";
                }else{
                    mensagem = "Erro ao desativar";
                }
            }
        }catch(Exception e){
            out.print(e);
            mensagem = "Erro ao executar";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='adminListarAlunos.jsp';");
        out.println("</script>");        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter out = response.getWriter();
        
        String idAluno = request.getParameter("idAluno");
        String nome = request.getParameter("nome");
        String email = request.getParameter("email");
        String cpf = request.getParameter("cpf");
        String telefone = request.getParameter("telefone");
        String data_nasc = request.getParameter("data_nasc");
        String cep = request.getParameter("cep");
        String logradouro = request.getParameter("logradouro");
        String bairro = request.getParameter("bairro");
        String cidade = request.getParameter("cidade");
        String uf = request.getParameter("uf");
        String numeroString = request.getParameter("numero");
        String genero = request.getParameter("genero");
        String usuario = request.getParameter("usuario");
        String senha = request.getParameter("senha");
        String pagina = request.getParameter("pagina");
        Part filePart = request.getPart("foto");
        
        String mensagem = "";
        
        Aluno a = new Aluno();
      
        
        try{
           if(!idAluno.isEmpty()){
               a.setIdAluno(Integer.parseInt(idAluno));
           }
           if(nome.equals("") || nome.isEmpty() ||
              email.equals("") || email.isEmpty() ||
              cpf.equals("") || cpf.isEmpty() ||
              telefone.equals("") || telefone.isEmpty() ||
              data_nasc.equals("") || data_nasc.isEmpty() ||
              cep.equals("") || cep.isEmpty() ||
              logradouro.equals("") || logradouro.isEmpty() ||
              bairro.equals("") || bairro.isEmpty() ||
              cidade.equals("") || cidade.isEmpty() ||
              uf.equals("") || uf.isEmpty() ||
              numeroString.equals("") || numeroString.isEmpty() ||
              usuario.equals("") || usuario.isEmpty() ||
              senha.equals("") || senha.isEmpty()){
            }else{
               if (filePart != null && filePart.getSize() > 0) {
                    InputStream fileContent = filePart.getInputStream();
                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    while ((bytesRead = fileContent.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                    }
                    byte[] imageData = outputStream.toByteArray();
                    a.setImagem(imageData);
                    } else {
                        int sidAluno = Integer.parseInt(idAluno);
                        AlunoDAO aDAO = new AlunoDAO();
                        a = aDAO.getCarregaAlunoID(sidAluno);
                        byte[] imagemAtual = a.getImagem();
                        a.setImagem(imagemAtual);
                    }
              int numero = Integer.parseInt(numeroString);
              a.setNome(nome);
              a.setEmail(email);
              a.setCpf(cpf);
              a.setTelefone(telefone);
              a.setData_nasc(data_nasc);
              a.setGenero(genero);
              a.setCep(cep);
              a.setLogradouro(logradouro);
              a.setBairro(bairro);
              a.setCidade(cidade);
              a.setUf(uf);
              a.setNumero(numero);
              a.setUsuario(usuario);
              UsuarioDAO uDAO = new UsuarioDAO();
              String senhaCripto = uDAO.hashSenhaMD5(senha);
              a.setSenha(senhaCripto);
              AlunoDAO aDAO = new AlunoDAO();
              if (aDAO.alterarAluno(a)) {
              mensagem = "Atualizado com sucesso";
              }else{
              mensagem = "Erro ao atualizar";
              }
        }  
        }catch(Exception e){
            out.print(e);
            mensagem = "Erro ao executar";
        }   
        String alunoPerfil = "alunoPerfil.jsp";
        if(pagina.equals(alunoPerfil)){
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='alunoPerfil.jsp';");
        out.println("</script>"); 
        }else{
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='adminListarAlunos.jsp';");
        out.println("</script>"); 
        }         
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
