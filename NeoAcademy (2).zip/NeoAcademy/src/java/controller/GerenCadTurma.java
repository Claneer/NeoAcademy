/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Administrador;
import model.Curso;
import model.Turma;
import model.TurmaDAO;

/**
 *
 * @author 315273
 */
@WebServlet(name = "GerenCadTurma", urlPatterns = {"/geren_cad_turma.do"})
public class GerenCadTurma extends HttpServlet {

   

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String idTurma = request.getParameter("idTurma");
        String nome = request.getParameter("nome");
        String snumeroVagas = request.getParameter("numeroVagas");
        String sidCurso = request.getParameter("idCurso");
        String sidAdmin = request.getParameter("idAdmin");
        
        PrintWriter out = response.getWriter();
        String mensagem = "";
        
        Turma t = new Turma();
        
        try{
            if(!idTurma.isEmpty()){
                t.setIdTurma(Integer.parseInt(idTurma));
            }
            if(nome.equals("") || nome.isEmpty() ||
               snumeroVagas.equals("") || snumeroVagas.isEmpty() ||
               sidCurso.equals("") || sidCurso.isEmpty() ||
               sidAdmin.equals("") || sidAdmin.isEmpty()){
                mensagem = "Preencha todos os campos";
            }else{
                int idCurso = Integer.parseInt(sidCurso);
                int idAdmin = Integer.parseInt(sidAdmin);
                int numeroVagas = Integer.parseInt(snumeroVagas);
                t.setNome(nome);
                t.setNumeroVagas(numeroVagas);
                Curso c = new Curso();
                c.setIdCurso(idCurso);
                t.setCurso(c);
                Administrador a = new Administrador();
                a.setIdAdmin(idAdmin);
                t.setAdministrador(a);
                TurmaDAO tDAO = new TurmaDAO();
                if(tDAO.gravarTurma(t)){
                    mensagem = "Gravado com sucesso";
                }else{
                    mensagem = "Erro ao gravar no banco de dados";
                }
            }      
        }catch(Exception e){
            out.print(e);
            mensagem = "Erro ao executar";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='admin.jsp';");
        out.println("</script>");  
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
