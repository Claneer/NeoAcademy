/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Administrador;
import model.AdministradorDAO;
import model.Aluno;
import model.AlunoDAO;
import model.Professor;
import model.ProfessorDAO;
import model.UsuarioDAO;

/**
 *
 * @author Victor
 */
@WebServlet(name = "GerenciaLogin", urlPatterns = {"/gerenciar_login.do"})



    public class GerenciarLogin extends HttpServlet {

        private static HttpServletResponse response;
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.getSession().removeAttribute("alogado");
        request.getSession().removeAttribute("plogado");
        request.getSession().removeAttribute("alulogado");
        response.sendRedirect("index.jsp");
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        GerenciarLogin.response = response;
        String usuario = request.getParameter("usuario");
        String senha = request.getParameter("senha");
        ArrayList<String> erros = new ArrayList<String>();
        if(usuario == null || usuario.trim().isEmpty()){
            erros.add("Preencha o usuario");   
        }
        if(senha == null || senha.trim().isEmpty()){
            erros.add("Preencha a senha");
        }
        if(erros.size()>0){
            String campos = "";
            for(String erro: erros){
                campos = campos + "\\n" + erro;
            }
            exibirMensagem("Preencha os campos:"+campos);
        }else{
            
            try{
                AdministradorDAO aDAO = new AdministradorDAO();
                Administrador a = new Administrador();
                a = aDAO.getLoginAdmin(usuario);
                UsuarioDAO uDAO = new UsuarioDAO();
                String senhaCripto = uDAO.hashSenhaMD5(senha);
                if(a.getUsuario() != null && !a.getUsuario().isEmpty() && a.getSenha().equals(senhaCripto) && a.getStatus() != 0){
                    HttpSession sessao = request.getSession();
                    sessao.setMaxInactiveInterval(36000);
                    RequestDispatcher disp = getServletContext().getRequestDispatcher("/admin.jsp");
                    sessao.setAttribute("alogado", a);
                    disp.forward(request, response);
                    return;
                }
                
                ProfessorDAO pDAO = new ProfessorDAO();
                Professor p = new Professor();
                p = pDAO.getLoginProf(usuario);
                if(p.getUsuario() != null && !p.getUsuario().isEmpty() && p.getSenha().equals(senhaCripto) && p.getStatus() != 0){
                    HttpSession sessao = request.getSession();
                    sessao.setMaxInactiveInterval(36000);
                    RequestDispatcher disp = getServletContext().getRequestDispatcher("/prof.jsp");
                    sessao.setAttribute("plogado", p);
                    disp.forward(request, response);
                    return;
                }
                    
                AlunoDAO alDAO = new AlunoDAO();
                Aluno al = new Aluno();
                al = alDAO.getLoginAluno(usuario);
                if(al.getUsuario() != null && !al.getUsuario().isEmpty() && al.getSenha().equals(senhaCripto) && al.getStatus() != 0){
                    HttpSession sessao = request.getSession();
                    sessao.setMaxInactiveInterval(36000);
                    RequestDispatcher disp = getServletContext().getRequestDispatcher("/aluno.jsp");
                    sessao.setAttribute("alulogado", al);
                    disp.forward(request, response);
                    return;
                }
                
                if(a.getUsuario() != null && !a.getUsuario().isEmpty() && a.getSenha().equals(senha) && a.getStatus() == 0){
                    exibirMensagem("Conta desativada, entre em contato com o suporte");
                }
                if(p.getUsuario() != null && !p.getUsuario().isEmpty() && p.getSenha().equals(senha) && p.getStatus() == 0){
                    exibirMensagem("Conta desativada, entre em contato com o suporte");
                }
                if(al.getUsuario() != null && !al.getUsuario().isEmpty() && al.getSenha().equals(senha) && al.getStatus() == 0){
                    exibirMensagem("Conta desativada, entre em contato com o suporte");
                }
                exibirMensagem("Usuário ou senha inválidos");
                
                                
            }catch(Exception e){
                exibirMensagem("Usuário não encontrado");
            }
        }
    }
    
    private static void exibirMensagem(String mensagem){
        
        try{
            PrintWriter out = response.getWriter();
            out.print("<script>");
            out.print("alert('"+mensagem+"');");
            out.print("history.back();");
            out.append("</script>");
            out.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
       /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
