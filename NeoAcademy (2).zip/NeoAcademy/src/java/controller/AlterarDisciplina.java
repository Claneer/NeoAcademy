/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Curso;
import model.Disciplina;
import model.DisciplinaDAO;
import model.Professor;

/**
 *
 * @author Victor
 */
@WebServlet(name = "AlterarDisciplina", urlPatterns = {"/alterar_disciplina.do"})
public class AlterarDisciplina extends HttpServlet {


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String acao = request.getParameter("acao");
        String idDisciplina = request.getParameter("idDisciplina");
        
        PrintWriter out = response.getWriter();
        String mensagem = "";
        Disciplina d = new Disciplina();
        
        try{
            DisciplinaDAO dDAO = new DisciplinaDAO();
            if(acao.equals("alterar")){
                d = dDAO.getCarregaDisciplinaID(Integer.parseInt(idDisciplina));
                if(d.getIdDisciplina()>0){
                    RequestDispatcher disp = getServletContext().getRequestDispatcher("/adminAlteraDisciplina.jsp");
                    request.setAttribute("id", d);
                    disp.forward(request, response);
                }else{
                    mensagem = "Perfil não encontrado";
                }
                }
                if(acao.equals("deletar")){
                d.setIdDisciplina(Integer.parseInt(idDisciplina));
                if(dDAO.Deletar(d)){
                    mensagem = "Deletado com sucesso";
                }else{
                    mensagem = "Erro ao excluir";
                }
            }            
        }catch(Exception e){
            out.print(e);
            mensagem = "Erro ao executar";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='admin.jsp';");
        out.println("</script>"); 
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String idDisciplina = request.getParameter("idDisciplina");
        String nome = request.getParameter("nome");
        String scargaHoraria = request.getParameter("cargaHoraria");
        String sidProfessor = request.getParameter("idProfessor");
        String sidCurso = request.getParameter("idCurso");
        
        PrintWriter out = response.getWriter();
        
        String mensagem = "";
        
        Disciplina d = new Disciplina();
        
        try{
            if(!idDisciplina.isEmpty()){
                d.setIdDisciplina(Integer.parseInt(idDisciplina));
            }
            if(nome.equals("") || nome.isEmpty() ||
               scargaHoraria.equals("") || scargaHoraria.isEmpty() ||
               sidProfessor.equals("") || sidProfessor.isEmpty() ||
               sidCurso.equals("") || sidCurso.isEmpty()){
                mensagem = "Preencha todos os campos";
            }else{
                int cargaHoraria = Integer.parseInt(scargaHoraria);
                int idProfessor = Integer.parseInt(sidProfessor);
                int idCurso = Integer.parseInt(sidCurso);
                d.setNome(nome);
                d.setCargaHoraria(cargaHoraria);
                Curso c = new Curso();
                c.setIdCurso(idCurso);
                d.setCurso(c);
                Professor p = new Professor();
                p.setIdProfessor(idProfessor);
                d.setProfessor(p);
                DisciplinaDAO dDAO = new DisciplinaDAO();
                if(dDAO.alterarDisciplina(d)){
                    mensagem = "Atualizado com sucesso";
                }else{
                    mensagem = "Erro ao atualizar no banco de dados";
                }
            }
        }catch(Exception e){
            out.print(e);
            mensagem = "Erro ao executar";
        } 
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='admin.jsp';");
        out.println("</script>");  
    }
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
