/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Usuario;
import model.UsuarioDAO;

/**
 *
 * @author Victor
 */
public class RecuperarSenha3 extends HttpServlet {


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null) {
        session.invalidate();
        response.sendRedirect("index.jsp");
        } else {
        response.sendRedirect("index.jsp");
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter out = response.getWriter();
        

        String cpf = request.getParameter("cpf");
        String email = request.getParameter("email");
        String data_nasc = request.getParameter("data_nasc");
 
        
        String mensagem = "";
        
        Usuario u = new Usuario();
        
        try{
            if(cpf.equals("") || cpf.isEmpty()){
                mensagem = "Preencha o campo de CPF";
            }else{
                HttpSession session = request.getSession();
                session.setAttribute("re_senha3", true);
                u.setEmail(email);
                u.setData_nasc(data_nasc);
                String ultimosTresDigitos = cpf.substring(cpf.length() - 3);
                u.setCpf(ultimosTresDigitos);
                UsuarioDAO uDAO = new UsuarioDAO();
                if(uDAO.recuperarCpf(u)){
                    RequestDispatcher disp = getServletContext().getRequestDispatcher("/redefinirSenha.jsp");
                    request.setAttribute("email", email);
                    request.setAttribute("data_nasc", data_nasc);
                    request.setAttribute("cpf", ultimosTresDigitos);
                    disp.forward(request, response); 
                }else{
                    mensagem = "Combinação de dados não existente";
                }
            }
        }catch(Exception e){
            mensagem = "Erro de execução";
            out.println(e);
        }
        
        out.println("<script type='text/javascript'>");
        out.println("alert('" + mensagem + "');");
        out.println("location.href='index.jsp';");
        out.println("</script>");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
