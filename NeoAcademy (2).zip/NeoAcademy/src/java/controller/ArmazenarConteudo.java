/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Cartao;
import model.CartaoDAO;
import model.Disciplina;
import model.Material;
import model.MaterialDAO;
import model.Professor;

/**
 *
 * @author Victor
 */
@WebServlet(name = "ArmazenarConteudo", urlPatterns = {"/armazenar_conteudo.do"})
public class ArmazenarConteudo extends HttpServlet {


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter out = response.getWriter();
        String mensagem = "";
        
        String acao = request.getParameter("acao");
        String idCartao = request.getParameter("idCartao");
        
        Cartao c = new Cartao();
        
        try{
            CartaoDAO cDAO = new CartaoDAO();
//            if(acao.equals("alterar")){
//                a = aDAO.getCarregaAlunoID(Integer.parseInt(idAluno));
//                if(a.getIdAluno()>0){
//                RequestDispatcher disp = getServletContext().getRequestDispatcher("/adminAlteraAluno.jsp");
//                request.setAttribute("id", a);
//                disp.forward(request, response);
//            }else{
//                mensagem = "Perfil não encontrado";
//            }   
//            }
            if(acao.equals("deletar")){
                c.setIdCartao(Integer.parseInt(idCartao));
                if(cDAO.Deletar(c)){
                    mensagem = "Deletado com sucesso";
                }else{
                    mensagem = "Erro ao excluir";
                }
            }
            if(acao.equals("ativar")){
                int sidCartao = Integer.parseInt(idCartao);
                if(cDAO.Ativar(sidCartao)){
                    mensagem = "Ativado com sucesso";
                }else{
                    mensagem = "Erro ao ativar";
                }
            }
            if(acao.equals("desativar")){
                int sidCartao = Integer.parseInt(idCartao);
                if(cDAO.Desativar(sidCartao)){
                    mensagem = "Desativado com sucesso";
                }else{
                    mensagem = "Erro ao desativar";
                }
            }
        }catch(Exception e){
            out.print(e);
            mensagem = "Erro ao executar";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='alunoMeusCartoes.jsp';");
        out.println("</script>");  
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        String nome = request.getParameter("nome");
        String tipo = request.getParameter("tipo");
        String orientacao = request.getParameter("orientacao");
        String url = request.getParameter("url");
        String idMaterial = request.getParameter("idMaterial");
        String sidDisciplina = request.getParameter("idDisciplina");
        String sidProfessor = request.getParameter("idProfessor");
        
        PrintWriter out = response.getWriter();
        String mensagem = "";
        
        Material m = new Material();
        
        try{
            if(!idMaterial.isEmpty()){
                m.setIdMaterial(Integer.parseInt(idMaterial));
            }   
                int idDisciplina = Integer.parseInt(sidDisciplina);
                int idProfessor = Integer.parseInt(sidProfessor);
                m.setNome(nome);
                m.setTipo(tipo);
                m.setOrientacao(orientacao);
                m.setUrl(url);
                Disciplina d = new Disciplina();
                d.setIdDisciplina(idDisciplina);
                m.setDisciplina(d);
                Professor p = new Professor();
                p.setIdProfessor(idProfessor);
                m.setProfessor(p);
                MaterialDAO mDAO = new MaterialDAO();
                if(mDAO.gravarMaterial(m)){
                    mensagem = "Conteúdo gravado com sucesso";
                }else{
                    mensagem = "Erro ao gravar o conteúdo no banco de dados";
                }
        }catch(Exception e){
            out.print(e);
            mensagem = "Erro ao executar";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='prof.jsp';");
        out.println("</script>");  
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
