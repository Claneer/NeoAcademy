/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Cartao;
import model.CartaoDAO;

/**
 *
 * @author Victor
 */
@WebServlet(name = "GerenLinkAvaliacao", urlPatterns = {"/geren_link_avaliacao.do"})
public class GerenLinkAvaliacao extends HttpServlet {


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter out = response.getWriter();
        String mensagem = "";
        // Obter a sessão do usuário
         HttpSession session = request.getSession();
        // Obter ou criar o conjunto de links acessados na sessão
        HashSet<String> accessedLinks = (HashSet<String>) session.getAttribute("linkAcessado");
        if (accessedLinks == null) {
            accessedLinks = new HashSet<String>();
            session.setAttribute("linkAcessado", accessedLinks);
        }
        Integer clickCount = (Integer) session.getAttribute("clickCount");
        if (clickCount == null) {
            clickCount = 0;
            session.setAttribute("clickCount", clickCount);
        }
        int maxClicks = 1;
        // Montar o identificador único do link de avaliação
        String idProfessor = request.getParameter("idProfessor");
        String idDisciplina = request.getParameter("idDisciplina");
        String idCurso = request.getParameter("idCurso");
        String linkId = "avaliacao_" + idProfessor + "_" + idDisciplina + "_" + idCurso;
         if (accessedLinks.contains(linkId)) {
             if(clickCount >= maxClicks){
            // Se o link já foi acessado, exibir uma mensagem de erro
            mensagem = "Você já realizou essa avaliação";
            out.println("<script type='text/javascript'>");
            out.println("alert('"+mensagem+"');");
            out.println("location.href='alunoMaterial.jsp';");
            out.println("</script>"); 
        }
         }else{
            // Marcar o link como acessado e redirecionar para a página de avaliação
            session.setAttribute("clickCount", clickCount + 1);
            accessedLinks.add(linkId);
            response.sendRedirect("alunoAvaliacao.jsp?idProfessor=" + idProfessor + "&idDisciplina=" + idDisciplina + "&idCurso=" + idCurso);
        }
    }


    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String idCartaoString = request.getParameter("idCartao");
        String idCurso = request.getParameter("idCurso");
        String idAluno = request.getParameter("idAluno");
        String preco = request.getParameter("preco");

        request.setAttribute("idCurso", idCurso);
        request.setAttribute("idAluno", idAluno);
        request.setAttribute("preco", preco);
        
        String mensagem = "";
        PrintWriter out = response.getWriter();
        
        try{
            if (idCartaoString != null && !idCartaoString.isEmpty()) {
            int idCartao = Integer.parseInt(idCartaoString);
            CartaoDAO cDAO = new CartaoDAO();
            Cartao cartao = cDAO.getCarregaCartaoID(idCartao);
                if (cartao != null) {
                    request.setAttribute("cartao", cartao);
                }
            }
        }catch(Exception e){
            System.out.println(e);
                mensagem = "Erro ao executar";
        }
        request.getRequestDispatcher("alunoPagamento.jsp").forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
