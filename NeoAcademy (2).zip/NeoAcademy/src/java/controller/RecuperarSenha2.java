/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.sql.Date;
import java.text.SimpleDateFormat;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Usuario;
import model.UsuarioDAO;

/**
 *
 * @author Victor
 */
public class RecuperarSenha2 extends HttpServlet {

   

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { 
        HttpSession session = request.getSession(false);
        if (session != null) {
        session.invalidate();
        response.sendRedirect("index.jsp");
        } else {
        response.sendRedirect("index.jsp");
        }
        }   
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        PrintWriter out = response.getWriter();
        
        String mensagem = "";
                
        String email = request.getParameter("email");
        String data_nasc = request.getParameter("data_nasc"); 
               
        Usuario u = new Usuario();
             
        try{
            if(data_nasc.equals("") || data_nasc.isEmpty()){
                mensagem = "Preencha o campo de data de nascimento";
                out.println("<script type='text/javascript'>");
        out.println("alert('" + mensagem + "');");
        out.println("location.href='recuperaSenha2.jsp';");
        out.println("</script>");
            }else{
                HttpSession session = request.getSession(true);
                session.setAttribute("re_senha2", true);
                u.setEmail(email);
                u.setData_nasc(data_nasc);
                UsuarioDAO uDAO = new UsuarioDAO();
                if(uDAO.recuperarNasc(u)){
                    RequestDispatcher disp = getServletContext().getRequestDispatcher("/recuperaSenha3.jsp");
                    request.setAttribute("email", email);
                    request.setAttribute("data_nasc", data_nasc);
                    disp.forward(request, response);    
                }else{
                    mensagem = "Dados não presente";
                    out.println("<script type='text/javascript'>");
        out.println("alert('" + mensagem + "');");
        out.println("location.href='recuperaSenha2.jsp';");
        out.println("</script>");
                } 
            }
        }catch(Exception e){
            out.println(e);
            mensagem = "Erro de execução";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('" + mensagem + "');");
        out.println("location.href='index.jsp';");
        out.println("</script>");
    }
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
