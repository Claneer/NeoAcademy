/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Aluno;
import model.Avaliacao;
import model.AvaliacaoDAO;
import model.Disciplina;
import model.DisciplinaDAO;
import model.NotasCursoDAO;
import model.NotasDisc;
import model.NotasDiscDAO;
import model.Professor;

/**
 *
 * @author Victor
 */
@WebServlet(name = "ChecarResposta", urlPatterns = {"/checar_resposta.do"})
public class ChecarResposta extends HttpServlet {
 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String sidAluno = request.getParameter("idAluno");
        String sidDisciplina = request.getParameter("idDisciplina");
        String sidProfessor = request.getParameter("idProfessor");
        String sidCurso = request.getParameter("idCurso");
        
        PrintWriter out = response.getWriter();
        String mensagem = "";
        int corretas = 0;
        int incorretas = 0;
        double nota = 0.0;
        
        
        try{
            AvaliacaoDAO avDAO = new AvaliacaoDAO();
            int idProfessor = Integer.parseInt(sidProfessor);
            int idDisciplina = Integer.parseInt(sidDisciplina);
            List<Avaliacao> listaAvaliacao = avDAO.getListaAvaliacao(idProfessor, idDisciplina);

        for (Avaliacao av : listaAvaliacao) {
            String nomeParametroResposta = "resp_" + av.getIdAvaliacao();
            String respostaSelecionada = request.getParameter(nomeParametroResposta);
            
            String respostaCorreta = av.getAlterCerta();
            
            if (respostaSelecionada != null && respostaSelecionada.equals(respostaCorreta)) {
                corretas++;
                nota += av.getValor();  
            } else {
                incorretas++;
            }               
        }               
        int total = corretas + incorretas;
        double porc_certas = (corretas * 100.0) / total;
        double porc_erradas = (incorretas * 100.0) / total;
        
        if(nota > 10){
            nota = 10;
        }

        int idCurso = Integer.parseInt(sidCurso);
        DisciplinaDAO dDAO = new DisciplinaDAO();
        int contaDisciplina = dDAO.contaDisciplina(idCurso);
        double mediaNota = nota / contaDisciplina;
        
        mensagem = "Respostas corretas: " + porc_certas + "%, Respostas incorretas: " + porc_erradas + "% "
                + "sua nota é: " + nota;

        int idAluno = Integer.parseInt(sidAluno);
        NotasDisc n = new NotasDisc();
        n.setNota(mediaNota);
        Professor p = new Professor();
        p.setIdProfessor(idProfessor);
        n.setProfessor(p);
        Disciplina d = new Disciplina();
        d.setIdDisciplina(idDisciplina);
        n.setDisciplina(d);
        Aluno a = new Aluno();
        a.setIdAluno(idAluno);
        n.setAluno(a);
        NotasDiscDAO nDAO = new NotasDiscDAO();
        nDAO.gravarNotas(n);
        int fkCurso = dDAO.getFkCursoDisciplina(idDisciplina);
        if(idCurso == fkCurso){
        NotasCursoDAO ncDAO = new NotasCursoDAO();
        ncDAO.gravarNotaFinal(idAluno, idCurso);
        }
        }catch(Exception ex){
            out.print(ex);
            mensagem = "Erro ao executar";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='alunoListarNotas.jsp';");
        out.println("</script>"); 
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
