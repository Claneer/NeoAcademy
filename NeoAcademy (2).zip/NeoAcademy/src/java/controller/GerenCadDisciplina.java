/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Administrador;
import model.Curso;
import model.Disciplina;
import model.DisciplinaDAO;
import model.Professor;

/**
 *
 * @author Victor
 */
@WebServlet(name = "GerenCadDisciplina", urlPatterns = {"/geren_cad_disciplina.do"})
public class GerenCadDisciplina extends HttpServlet {


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        String nome = request.getParameter("nome");
        String scargaHoraria = request.getParameter("cargaHoraria");
        String idDisciplina = request.getParameter("idDisciplina");
        String sidProfessor = request.getParameter("idProfessor");
        String sidCurso = request.getParameter("idCurso");
        String sidAdmin = request.getParameter("idAdmin");
        
        PrintWriter out = response.getWriter();
        
        String mensagem = "";
        
        Disciplina d = new Disciplina();
        
        try{
            if(!idDisciplina.isEmpty()){
                d.setIdDisciplina(Integer.parseInt(idDisciplina));
            }
            if(nome.equals("") || nome.isEmpty() ||
               scargaHoraria.equals("") || scargaHoraria.isEmpty() ||
               sidProfessor.equals("") || sidProfessor.isEmpty() ||
               sidCurso.equals("") || sidCurso.isEmpty() ||
               sidAdmin.equals("") || sidAdmin.isEmpty()){
                mensagem = "Preencha todos os campos";
            }else{
                int cargaHoraria = Integer.parseInt(scargaHoraria);
                int idProfessor = Integer.parseInt(sidProfessor);
                int idCurso = Integer.parseInt(sidCurso);
                int idAdmin = Integer.parseInt(sidAdmin);
                d.setNome(nome);
                d.setCargaHoraria(cargaHoraria);
                Curso c = new Curso();
                c.setIdCurso(idCurso);
                d.setCurso(c);
                Professor p = new Professor();
                p.setIdProfessor(idProfessor);
                d.setProfessor(p);
                Administrador a = new Administrador();
                a.setIdAdmin(idAdmin);
                d.setAdministrador(a);
                DisciplinaDAO dDAO = new DisciplinaDAO();
                if(dDAO.gravarDisciplina(d)){
                    mensagem = "Gravado com sucesso";
                }else{
                    mensagem = "Erro ao gravar no banco de dados";
                }
            }
        }catch(Exception e){
            out.print(e);
            mensagem = "Erro ao executar";
        } 
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='admin.jsp';");
        out.println("</script>");  
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
