/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Administrador;
import model.Curso;
import model.Turma;
import model.TurmaDAO;
import model.Professor;

/**
 *
 * @author 315273
 */
@WebServlet(name = "AlterarTurma", urlPatterns = {"/alterar_turma.do"})
public class AlterarTurma extends HttpServlet {


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        String acao = request.getParameter("acao");
        String idTurma = request.getParameter("idTurma");
        
        PrintWriter out = response.getWriter();
        String mensagem = "";
        Turma t = new Turma();
        
        try{
            TurmaDAO tDAO = new TurmaDAO();
            if(acao.equals("alterar")){
                t = tDAO.getCarregaTurmaID(Integer.parseInt(idTurma));
                if(t.getIdTurma()>0){
                    RequestDispatcher disp = getServletContext().getRequestDispatcher("/adminAlteraTurma.jsp");
                    request.setAttribute("id", t);
                    disp.forward(request, response);
                }else{
                    mensagem = "Perfil não encontrado";
                }
                }
                if(acao.equals("deletar")){
                t.setIdTurma(Integer.parseInt(idTurma));
                if(tDAO.Deletar(t)){
                    mensagem = "Deletado com sucesso";
                }else{
                    mensagem = "Erro ao excluir";
                }
            }            
        }catch(Exception e){
            out.print(e);
            mensagem = "Erro ao executar";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='admin.jsp';");
        out.println("</script>"); 
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String idTurma = request.getParameter("idTurma");
        String nome = request.getParameter("nome");
        String snumeroVagas = request.getParameter("numeroVagas");
        
        PrintWriter out = response.getWriter();
        String mensagem = "";
        
        Turma t = new Turma();
        
        try{
            if(!idTurma.isEmpty()){
                t.setIdTurma(Integer.parseInt(idTurma));
            }
            if(nome.equals("") || nome.isEmpty() ||
               snumeroVagas.equals("") || snumeroVagas.isEmpty()){
                mensagem = "Preencha todos os campos";
            }else{
                int numeroVagas = Integer.parseInt(snumeroVagas);
                t.setNome(nome);
                t.setNumeroVagas(numeroVagas);
                TurmaDAO tDAO = new TurmaDAO();
                if(tDAO.alterarTurma(t)){
                    mensagem = "Atualizado com sucesso";
                }else{
                    mensagem = "Erro ao atualizar no banco de dados";
                }
            }      
        }catch(Exception e){
            out.print(e);
            mensagem = "Erro ao executar";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='admin.jsp';");
        out.println("</script>");  
    }
    

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
