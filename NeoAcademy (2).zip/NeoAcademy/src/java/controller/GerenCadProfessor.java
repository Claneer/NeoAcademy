/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Administrador;
import model.AdministradorDAO;
import model.Professor;
import model.ProfessorDAO;
import model.UsuarioDAO;

/**
 *
 * @author Victor
 */
@WebServlet(name = "GerenCadProfessor", urlPatterns = {"/geren_cad_professor.do"})
public class GerenCadProfessor extends HttpServlet {

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter out = response.getWriter();        
        String idProfessor = request.getParameter("idProfessor");
        String nome = request.getParameter("nome");
        String email = request.getParameter("email");
        String cpf = request.getParameter("cpf");
        String telefone = request.getParameter("telefone");
        String data_nasc = request.getParameter("data_nasc");
        String cep = request.getParameter("cep");
        String logradouro = request.getParameter("logradouro");
        String bairro = request.getParameter("bairro");
        String cidade = request.getParameter("cidade");
        String uf = request.getParameter("uf");
        String numeroString = request.getParameter("numero");
        String genero = request.getParameter("genero");
        String usuario = request.getParameter("usuario");
        String senha = request.getParameter("senha");
        String confirmarsenha = request.getParameter("confirmarsenha");
        String salarioString = request.getParameter("salario");
        String sidAdmin = request.getParameter("idAdmin");
        String regex = "\\d{10,11}";
        
        String mensagem = "";
        
        Professor p = new Professor();
        boolean valido = false;
        
        
        try{
           if(!idProfessor.isEmpty()){
               p.setIdProfessor(Integer.parseInt(idProfessor));
           }
           
           if(nome.equals("") || nome.isEmpty() ||
              email.equals("") || email.isEmpty() ||
              cpf.equals("") || cpf.isEmpty() ||
              telefone.equals("") || telefone.isEmpty() ||
              data_nasc.equals("") || data_nasc.isEmpty() ||
              cep.equals("") || cep.isEmpty() ||
              logradouro.equals("") || logradouro.isEmpty() ||
              bairro.equals("") || bairro.isEmpty() ||
              cidade.equals("") || cidade.isEmpty() ||
              uf.equals("") || uf.isEmpty() ||
              numeroString.equals("") || numeroString.isEmpty() ||
              usuario.equals("") || usuario.isEmpty() ||
              senha.equals("") || senha.isEmpty() ||
              confirmarsenha.equals("") || confirmarsenha.isEmpty() ||
              salarioString.equals("") || salarioString.isEmpty() ||
                   sidAdmin.equals("") || sidAdmin.isEmpty()){
            }else{
                UsuarioDAO uDAO = new UsuarioDAO();
                if (cpf != null && cpf.matches("\\d{11}")){
                    valido = uDAO.validaCPF(cpf);
                }
                if (valido){
                    p.setCpf(cpf);
                }else{
                    mensagem = "CPF inválido";
                    out.println("<script type='text/javascript'>");
                    out.println("alert('"+mensagem+"');");
                    out.println("location.href='cadastraAluno.jsp';");
                    out.println("</script>");
                }
                if (telefone.matches(regex)){
                    p.setTelefone(telefone);
                }else{
                    mensagem = "Número de telefone inválido";
                    out.println("<script type='text/javascript'>");
                    out.println("alert('"+mensagem+"');");
                    out.println("location.href='cadastraAluno.jsp';");
                    out.println("</script>");
                }
              if(!senha.equals(confirmarsenha)){
                 mensagem = "As senhas são diferentes";
              }
              int idAdmin = Integer.parseInt(sidAdmin);
              double salario = Double.parseDouble(salarioString);
              int numero = Integer.parseInt(numeroString);
              p.setNome(nome);
              p.setEmail(email);
              p.setData_nasc(data_nasc);
              p.setGenero(genero);
              p.setCep(cep);
              p.setLogradouro(logradouro);
              p.setBairro(bairro);
              p.setCidade(cidade);
              p.setUf(uf);
              p.setNumero(numero);
              p.setUsuario(usuario); 
              String senhaCripto = uDAO.hashSenhaMD5(senha);
              p.setSenha(senhaCripto);
              p.setSalario(salario);
              Administrador a = new Administrador();
              a.setIdAdmin(idAdmin);
              p.setAdministrador(a);
              ProfessorDAO pDAO = new ProfessorDAO();
              if (pDAO.gravarProfessor(p)) {
              mensagem = "Gravado com sucesso";
              }else{
              mensagem = "Erro ao gravar no banco de dados";
              }
        }  
        }catch(Exception e){
            out.print(e);
            mensagem = "Erro ao executar";
        }   
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='admin.jsp';");
        out.println("</script>");        
    }
}

