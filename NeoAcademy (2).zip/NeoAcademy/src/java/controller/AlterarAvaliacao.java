/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Avaliacao;
import model.AvaliacaoDAO;
import model.Professor;

/**
 *
 * @author Victor
 */
@WebServlet(name = "AlterarAvaliacao", urlPatterns = {"/alterar_avaliacao.do"})
public class AlterarAvaliacao extends HttpServlet {


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter out = response.getWriter();
        String mensagem = "";
        
        String acao = request.getParameter("acao");
        String idAvaliacao = request.getParameter("idAvaliacao");
        
        Avaliacao av = new Avaliacao();
        
        try{
            AvaliacaoDAO avDAO = new AvaliacaoDAO();
            if(acao.equals("alterar")){
                av = avDAO.getCarregaAvaliacaoID(Integer.parseInt(idAvaliacao));
                if(av.getIdAvaliacao()>0){
                RequestDispatcher disp = getServletContext().getRequestDispatcher("/profAlteraAvaliacao.jsp");
                request.setAttribute("id", av);
                disp.forward(request, response);
            }else{
                mensagem = "Perfil não encontrado";
            }   
            }
            if(acao.equals("deletar")){
                av.setIdAvaliacao(Integer.parseInt(idAvaliacao));
                if(avDAO.Deletar(av)){
                    mensagem = "Deletado com sucesso";
                }else{
                    mensagem = "Erro ao excluir";
                }
            }
        }catch(Exception e){
            out.print(e);
            mensagem = "Erro ao executar";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='profListarAvaliacao.jsp';");
        out.println("</script>");        
    }
       
    

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String pergunta = request.getParameter("questao");
            String a = request.getParameter("alterA");
            String b = request.getParameter("alterB");
            String c = request.getParameter("alterC");
            String d = request.getParameter("alterD");
            String e = request.getParameter("alterE");
            String certa = request.getParameter("alterCerta");
            String svalor = request.getParameter("valor");
            String idAvaliacao = request.getParameter("idAvaliacao");

            PrintWriter out = response.getWriter();
            String mensagem = "";
            
            Avaliacao av = new Avaliacao();
            
            try{
                if(!idAvaliacao.isEmpty()){
                    av.setIdAvaliacao(Integer.parseInt(idAvaliacao));
                }
                if(pergunta.equals("") || pergunta.isEmpty() || 
                        a.equals("") || a.isEmpty() ||
                        b.equals("") || b.isEmpty() ||
                        certa.equals("") || certa.isEmpty() ||
                        svalor.equals("") || svalor.isEmpty()){
                    mensagem = "Preencha todos os campos";
                }else{
                    double valor = Double.parseDouble(svalor);
                    av.setQuestao(pergunta);
                    av.setAlterA(a);
                    av.setAlterB(b);
                    av.setAlterC(c);
                    av.setAlterD(d);
                    av.setAlterE(e);
                    av.setAlterCerta(certa);
                    av.setValor(valor);
                    AvaliacaoDAO avDAO = new AvaliacaoDAO();
                    if(avDAO.AlterarAvaliacao(av)){
                        mensagem = "Questão atualizada com sucesso";
                    }else{
                        mensagem = "Erro ao atualizar a questão";
                    }
                }
            }catch(Exception ex){
                out.print(ex);
                mensagem = "Erro ao executar";
            }
            out.println("<script type='text/javascript'>");
            out.println("alert('"+mensagem+"');");
            out.println("location.href='profListarAvaliacao.jsp';");
            out.println("</script>"); 
    }
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
