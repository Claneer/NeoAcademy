
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class AdministradorDAO extends DatabaseDAO {
    
      
    public AdministradorDAO() throws Exception{}
    
    public boolean gravarAdministrador (Administrador a){
        try{
            this.conectar();
            String sql = "INSERT INTO administrador (nome, email, cpf, telefone, data_nasc, genero, cep, logradouro, bairro, "
                    + "cidade, uf, numero, usuario, senha, salario) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, a.getNome());
            pstm.setString(2, a.getEmail());
            pstm.setString(3, a.getCpf());
            pstm.setString(4, a.getTelefone());
            pstm.setString(5, a.getData_nasc());
            pstm.setString(6, a.getGenero());
            pstm.setString(7, a.getCep());
            pstm.setString(8, a.getLogradouro());
            pstm.setString(9, a.getBairro());
            pstm.setString(10, a.getCidade());
            pstm.setString(11, a.getUf());
            pstm.setInt(12, a.getNumero());
            pstm.setString(13, a.getUsuario());
            pstm.setString(14, a.getSenha());
            pstm.setDouble(15, a.getSalario());
            pstm.executeUpdate();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public ArrayList<Administrador> getListaAdministrador() throws Exception{
        
        ArrayList<Administrador> lista = new ArrayList<Administrador>();
        String SQL = "SELECT * FROM administrador";
        this.conectar();
        Statement stm = conn.createStatement();
        ResultSet rs = stm.executeQuery(SQL);
        while(rs.next()){
            Administrador a = new Administrador();
            a.setIdAdmin(rs.getInt("idAdmin"));
            a.setNome(rs.getString("nome"));
            a.setEmail(rs.getString("email"));
            a.setTelefone(rs.getString("telefone"));
            a.setUsuario(rs.getString("usuario"));
            a.setStatus(rs.getInt("status"));
            lista.add(a);
        }
        this.desconectar();
        return lista;
    }
    
    public Administrador getCarregaAdministradorID(int idAdmin) throws Exception{
        
        Administrador a = new Administrador();
        String sql = "SELECT * FROM administrador WHERE idAdmin = ?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idAdmin);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            a.setIdAdmin(rs.getInt("idAdmin"));
            a.setNome(rs.getString("nome"));
            a.setEmail(rs.getString("email"));
            a.setCpf(rs.getString("cpf"));
            a.setTelefone(rs.getString("telefone"));
            a.setData_nasc(rs.getString("data_nasc"));
            a.setCep(rs.getString("cep"));
            a.setLogradouro(rs.getString("logradouro"));
            a.setBairro(rs.getString("bairro"));
            a.setCidade(rs.getString("cidade"));
            a.setUf(rs.getString("uf"));
            a.setNumero(rs.getInt("numero"));
            a.setUsuario(rs.getString("usuario"));
            a.setSenha(rs.getString("senha"));
            a.setSalario(rs.getDouble("salario"));
            byte[] imagemBytes = rs.getBytes("foto");
            a.setImagem(imagemBytes);
        }
        this.desconectar();
        return a;
    }
    
    public boolean alterarAdministrador(Administrador p){
        
        try{
            this.conectar();
            String sql = "UPDATE administrador SET nome = ?, email = ?, cpf = ?, telefone = ?, data_nasc = ?,"
                    + " genero = ?, cep = ?, logradouro = ?, bairro = ?, cidade = ?, uf = ?, "
                    + "numero = ?, usuario = ?, senha = ?, salario = ?, foto = ? WHERE idAdmin = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1,p.getNome());
            pstm.setString(2,p.getEmail());
            pstm.setString(3,p.getCpf());
            pstm.setString(4,p.getTelefone());
            pstm.setString(5,p.getData_nasc());
            pstm.setString(6,p.getGenero());
            pstm.setString(7,p.getCep());
            pstm.setString(8,p.getLogradouro());
            pstm.setString(9,p.getBairro());
            pstm.setString(10,p.getCidade());
            pstm.setString(11,p.getUf());
            pstm.setInt(12,p.getNumero());
            pstm.setString(13,p.getUsuario());
            pstm.setString(14,p.getSenha());
            pstm.setDouble(15,p.getSalario());
            pstm.setBytes(16, p.getImagem());
            pstm.setInt(17, p.getIdAdmin());
            int linhasAfetadas = pstm.executeUpdate();
            this.desconectar();
            if(linhasAfetadas > 0){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public boolean Deletar(Administrador a){
        
        try{
            this.conectar();
            String sql = "DELETE FROM administrador WHERE idAdmin = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, a.getIdAdmin());
            pstm.execute();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public ArrayList<Administrador> getListaIdNomeAdministrador() throws Exception {
        
        ArrayList<Administrador> lista = new ArrayList<>();
        String SQL = "SELECT idAdmin, nome FROM administrador";
        try {
        this.conectar();
        Statement stm = conn.createStatement();
        ResultSet rs = stm.executeQuery(SQL);
        while (rs.next()) {
            Administrador a = new Administrador();
            a.setIdAdmin(rs.getInt("idAdmin"));
            a.setNome(rs.getString("nome"));
            lista.add(a);
        }
        }catch (Exception e) {
        System.out.println(e);;
        }
        this.desconectar();
        return lista;
    }
    
     public Administrador getLoginAdmin(String usuario){
         
         Administrador a = new Administrador();
         String sql = "SELECT a.* FROM administrador a WHERE a.usuario = ?";
         
         try{
             this.conectar();
             PreparedStatement pstm = conn.prepareStatement(sql);
             pstm.setString(1, usuario);
             ResultSet resultado = pstm.executeQuery();
             if(resultado.next()){
                 a.setIdAdmin(resultado.getInt("a.idAdmin"));
                 a.setNome(resultado.getString("a.nome"));
                 a.setUsuario(resultado.getString("a.usuario"));
                 a.setSenha(resultado.getString("a.senha"));
                 a.setStatus(resultado.getInt("a.status"));
             }
             this.desconectar();
             return a;
         }catch(Exception e){
             System.out.println(e);
             return null;
         }
         
     }
     
     public boolean Ativar(int idAdmin){
         
         try{
            this.conectar();
            String sql = "UPDATE administrador SET status = 1 WHERE idAdmin = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idAdmin);
            int linhasAfetadas = pstm.executeUpdate();
            this.desconectar();
            if(linhasAfetadas > 0){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
     }
     
     public boolean Desativar(int idAdmin){
         
         try{
            this.conectar();
            String sql = "UPDATE administrador SET status = 0 WHERE idAdmin = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idAdmin);
            int linhasAfetadas = pstm.executeUpdate();
            this.desconectar();
            if(linhasAfetadas > 0){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
     }
}
