
package model;

public class Disciplina {
    
    private String nome;
    private int idDisciplina;
    private int cargaHoraria;
    private double nota;
    private Professor professor;
    private Curso curso;
    private Administrador administrador;  

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdDisciplina() {
        return idDisciplina;
    }

    public void setIdDisciplina(int idDisciplina) {
        this.idDisciplina = idDisciplina;
    }

    public int getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(int cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public Administrador getAdministrador() {
        return administrador;
    }

    public void setAdministrador(Administrador administrador) {
        this.administrador = administrador;
    }

    @Override
    public String toString() {
        return "Disciplina{" + "nome=" + nome + ", idDisciplina=" + idDisciplina + ", "
                + "cargaHoraria=" + cargaHoraria + ", nota=" + nota + ", "
                + "professor=" + professor + ", curso=" + curso + ", administrador=" + administrador + '}';
    }  
}
