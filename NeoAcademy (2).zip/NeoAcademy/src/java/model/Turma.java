
package model;

public class Turma {
    
    private int idTurma;
    private String nome;
    private int numeroVagas;
    private Curso curso;
    private Administrador administrador;

    public int getIdTurma() {
        return idTurma;
    }

    public void setIdTurma(int idTurma) {
        this.idTurma = idTurma;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNumeroVagas() {
        return numeroVagas;
    }

    public void setNumeroVagas(int numeroVagas) {
        this.numeroVagas = numeroVagas;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public Administrador getAdministrador() {
        return administrador;
    }

    public void setAdministrador(Administrador administrador) {
        this.administrador = administrador;
    }

    @Override
    public String toString() {
        return "Turma{" + "idTurma=" + idTurma + ", nome=" + nome + ", numeroVagas=" + numeroVagas + ", "
                + "curso=" + curso + ", administrador=" + administrador + '}';
    }
}
