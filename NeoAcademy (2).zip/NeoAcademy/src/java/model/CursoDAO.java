
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class CursoDAO extends DatabaseDAO{
    
    public CursoDAO() throws Exception{}
    
    public boolean gravarCurso (Curso c){
        
        try{
            this.conectar();
            String sql = "INSERT INTO curso (nome, cargaHoraria, descricao, valor, idAdmin)"
                    + "VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, c.getNome());
            pstm.setInt(2, c.getCargaHoraria());
            pstm.setString(3, c.getDescricao());
            pstm.setDouble(4, c.getValor());
            pstm.setInt(5, c.getAdministrador().getIdAdmin());
            pstm.executeUpdate();
            this.desconectar();
            return true;     
        }catch(Exception e){
            System.out.println(e);
            return false;
        } 
    }
    
    public ArrayList<Curso> getListaCurso() throws Exception{
        
        ArrayList<Curso> lista = new ArrayList<Curso>();
        String SQL = "SELECT * FROM curso";
        this.conectar();
        Statement stm = conn.createStatement();
        ResultSet rs = stm.executeQuery(SQL);
        while(rs.next()){
            Curso c = new Curso();
            c.setIdCurso(rs.getInt("idCurso"));
            c.setNome(rs.getString("nome"));
            c.setCargaHoraria(rs.getInt("cargaHoraria"));
            c.setDescricao(rs.getString("descricao"));
            c.setValor(rs.getDouble("valor"));
            lista.add(c);
        }
        this.desconectar();
        return lista;
    }
    
    public Curso getCarregaCursoID(int idCurso) throws Exception{
        
        Curso c = new Curso();
        String sql = "SELECT * FROM curso WHERE idCurso = ?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idCurso);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            c.setIdCurso(rs.getInt("idCurso"));
            c.setDescricao(rs.getString("descricao"));
            c.setNome(rs.getString("nome"));
            c.setCargaHoraria(rs.getInt("cargaHoraria"));
            c.setValor(rs.getDouble("valor"));            
        }
        this.desconectar();
        return c;
    }
    
    public boolean alterarCurso(Curso c){
        
        try{
            this.conectar();
            String sql = "UPDATE curso SET nome = ?, cargaHoraria = ?, descricao = ?, valor = ? WHERE idCurso = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, c.getNome());
            pstm.setInt(2, c.getCargaHoraria());
            pstm.setString(3, c.getDescricao());
            pstm.setDouble(4, c.getValor());
            pstm.setInt(5, c.getIdCurso());
            int linhasAfetadas = pstm.executeUpdate();
            this.desconectar();
            if(linhasAfetadas > 0){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public boolean Deletar(Curso c){
        
        try{
            this.conectar();
            String sql = "DELETE FROM curso WHERE idCurso = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, c.getIdCurso());
            pstm.execute();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public ArrayList<Curso> getListaIdNomeCurso() throws Exception {
        
        ArrayList<Curso> lista = new ArrayList<>();
        String SQL = "SELECT idCurso, nome FROM curso";
        try {
        this.conectar();
        Statement stm = conn.createStatement();
        ResultSet rs = stm.executeQuery(SQL);
        while (rs.next()) {
            Curso a = new Curso();
            a.setIdCurso(rs.getInt("idCurso"));
            a.setNome(rs.getString("nome"));
            lista.add(a);
        }
        }catch (Exception e) {
        System.out.println(e);;
        }
        this.desconectar();
        return lista;
    }
    
    public Curso getNomeCurso(int idCurso)throws Exception{
        
        Curso c = new Curso();
        try{
            this.conectar();
            String sql = "SELECT nome FROM curso WHERE idCurso = ?";
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idCurso);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            c.setNome(rs.getString("nome"));
        }
        this.desconectar();
        }catch(Exception e){
            System.out.println(e);    
        }
        return c;
    }
}


