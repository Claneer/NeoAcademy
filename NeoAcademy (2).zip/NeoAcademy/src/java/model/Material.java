
package model;

public class Material {
    
    private int idMaterial;
    private String nome;
    private String tipo;
    private String url;
    private String orientacao;
    private Disciplina disciplina;
    private Professor professor;

    public int getIdMaterial() {
        return idMaterial;
    }

    public void setIdMaterial(int idMaterial) {
        this.idMaterial = idMaterial;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getOrientacao() {
        return orientacao;
    }

    public void setOrientacao(String orientacao) {
        this.orientacao = orientacao;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    @Override
    public String toString() {
        return "Material{" + "idMaterial=" + idMaterial + ", nome=" + nome + ", "
                + "tipo=" + tipo + ", url=" + url + ", orientacao=" + orientacao + ", "
                + "disciplina=" + disciplina + ", professor=" + professor + '}';
    }  
}
