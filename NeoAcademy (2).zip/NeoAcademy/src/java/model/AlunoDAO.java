
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class AlunoDAO extends DatabaseDAO {
    
    public AlunoDAO() throws Exception{}
    
    public boolean gravarAluno (Aluno a){
        try{
            this.conectar();
            String sql = "INSERT INTO aluno (nome, email, cpf, telefone, data_nasc, genero, cep, logradouro, bairro, "
                    + "cidade, uf, numero, usuario, senha) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, a.getNome());
            pstm.setString(2, a.getEmail());
            pstm.setString(3, a.getCpf());
            pstm.setString(4, a.getTelefone());
            pstm.setString(5, a.getData_nasc());
            pstm.setString(6, a.getGenero());
            pstm.setString(7, a.getCep());
            pstm.setString(8, a.getLogradouro());
            pstm.setString(9, a.getBairro());
            pstm.setString(10, a.getCidade());
            pstm.setString(11, a.getUf());
            pstm.setInt(12, a.getNumero());
            pstm.setString(13, a.getUsuario());
            pstm.setString(14, a.getSenha());
            pstm.executeUpdate();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public ArrayList<Aluno> getListaAluno() throws Exception{
        
        ArrayList<Aluno> lista = new ArrayList<Aluno>();
        String SQL = "SELECT * FROM aluno";
        this.conectar();
        Statement stm = conn.createStatement();
        ResultSet rs = stm.executeQuery(SQL);
        while(rs.next()){
            Aluno a = new Aluno();
            a.setIdAluno(rs.getInt("idAluno"));
            a.setNome(rs.getString("nome"));
            a.setEmail(rs.getString("email"));
            a.setTelefone(rs.getString("telefone"));
            a.setUsuario(rs.getString("usuario"));
            a.setStatus(rs.getInt("status"));
            lista.add(a);
        }
        this.desconectar();
        return lista;
    }
    
    public Aluno getCarregaAlunoID(int idAluno) throws Exception{
        
        Aluno a = new Aluno();
        String sql = "SELECT * FROM aluno WHERE idAluno = ?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idAluno);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            a.setIdAluno(rs.getInt("idAluno"));
            a.setNome(rs.getString("nome"));
            a.setEmail(rs.getString("email"));
            a.setCpf(rs.getString("cpf"));
            a.setTelefone(rs.getString("telefone"));
            a.setData_nasc(rs.getString("data_nasc"));
            a.setCep(rs.getString("cep"));
            a.setLogradouro(rs.getString("logradouro"));
            a.setBairro(rs.getString("bairro"));
            a.setCidade(rs.getString("cidade"));
            a.setUf(rs.getString("uf"));
            a.setNumero(rs.getInt("numero"));
            a.setUsuario(rs.getString("usuario"));
            a.setSenha(rs.getString("senha"));
            byte[] imagemBytes = rs.getBytes("foto");
            a.setImagem(imagemBytes);
        }
        this.desconectar();
        return a;
    }
    
    public boolean alterarAluno(Aluno a){
        
        try{
            this.conectar();
            String sql = "UPDATE aluno SET nome = ?, email = ?, cpf = ?, telefone = ?, data_nasc = ?,"
                    + " genero = ?, cep = ?, logradouro = ?, bairro = ?, cidade = ?, uf = ?, "
                    + "numero = ?, usuario = ?, senha = ?, foto = ? WHERE idAluno = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1,a.getNome());
            pstm.setString(2,a.getEmail());
            pstm.setString(3,a.getCpf());
            pstm.setString(4,a.getTelefone());
            pstm.setString(5,a.getData_nasc());
            pstm.setString(6,a.getGenero());
            pstm.setString(7,a.getCep());
            pstm.setString(8,a.getLogradouro());
            pstm.setString(9,a.getBairro());
            pstm.setString(10,a.getCidade());
            pstm.setString(11,a.getUf());
            pstm.setInt(12,a.getNumero());
            pstm.setString(13,a.getUsuario());
            pstm.setString(14,a.getSenha());
            pstm.setBytes(15, a.getImagem());
            pstm.setInt(16, a.getIdAluno());
            int linhasAfetadas = pstm.executeUpdate();
            this.desconectar();
            if(linhasAfetadas > 0){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public boolean Deletar(Aluno a){
        
        try{
            this.conectar();
            String sql = "DELETE FROM aluno WHERE idAluno = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, a.getIdAluno());
            pstm.execute();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public Aluno getLoginAluno(String usuario){
         
         Aluno al = new Aluno();
         String sql = "SELECT al.* FROM aluno al WHERE al.usuario = ?";
         
         try{
             this.conectar();
             PreparedStatement pstm = conn.prepareStatement(sql);
             pstm.setString(1, usuario);
             ResultSet resultado = pstm.executeQuery();
             if(resultado.next()){
                 al.setIdAluno(resultado.getInt("al.idAluno"));
                 al.setNome(resultado.getString("al.nome"));
                 al.setUsuario(resultado.getString("al.usuario"));
                 al.setSenha(resultado.getString("al.senha"));
                 al.setStatus(resultado.getInt("al.status"));
             }
             this.desconectar();
             return al;
         }catch(Exception e){
             System.out.println(e);
             return null;
         }
         
     }
    
    public Aluno getNomeAluno(int idProfessor, int idDisciplina) throws Exception{
        
        Aluno a = new Aluno();
        try{
             this.conectar();
             String sql = "SELECT a.idAluno, a.nome AS nomeAluno FROM aluno a "
                   + "INNER JOIN notasdisc nt ON a.idAluno = nt.idAluno "
                   + "WHERE nt.idProfessor = ? AND nt.idDisciplina = ?";
             PreparedStatement pstm = conn.prepareStatement(sql);
             pstm.setInt(1, idProfessor);
             pstm.setInt(2, idDisciplina);
             ResultSet rs = pstm.executeQuery();
             if(rs.next()){
                 a.setIdAluno(rs.getInt("idAluno"));
                 a.setNome(rs.getString("nomeAluno"));
             }
             this.desconectar();
         }catch(Exception e){
             System.out.println(e);
         }
        return a;
    }
    
    public boolean Ativar(int idAluno){
         
         try{
            this.conectar();
            String sql = "UPDATE aluno SET status = 1 WHERE idAluno = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idAluno);
            int linhasAfetadas = pstm.executeUpdate();
            this.desconectar();
            if(linhasAfetadas > 0){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
     }
     
     public boolean Desativar(int idAluno){
         
         try{
            this.conectar();
            String sql = "UPDATE aluno SET status = 0 WHERE idAluno = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idAluno);
            int linhasAfetadas = pstm.executeUpdate();
            this.desconectar();
            if(linhasAfetadas > 0){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
     }
}
