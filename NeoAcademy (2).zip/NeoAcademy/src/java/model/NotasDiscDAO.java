
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class NotasDiscDAO extends DatabaseDAO{
    
    public NotasDiscDAO() throws Exception{}
    
    public boolean gravarNotas (NotasDisc n){
        
        try{
            
            this.conectar();
            String sql = "INSERT INTO notasdisc (nota, idAluno, idDisciplina, idProfessor)"
                    + "VALUES (?, ?, ?, ?)";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setDouble(1, n.getNota());
            pstm.setInt(2, n.getAluno().getIdAluno());
            pstm.setInt(3, n.getDisciplina().getIdDisciplina());
            pstm.setInt(4, n.getProfessor().getIdProfessor());
            pstm.executeUpdate();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public ArrayList<NotasDisc> getListaNotas(int idProfessor) throws Exception{
        
        ArrayList<NotasDisc> lista = new ArrayList<NotasDisc>();
        String SQL = "SELECT * FROM notasdisc WHERE idProfessor = ?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(SQL);
        pstm.setInt(1, idProfessor);
        ResultSet rs = pstm.executeQuery();
        while(rs.next()){
            NotasDisc n = new NotasDisc();
            n.setIdNotas(rs.getInt("idNotas"));
            n.setNota(rs.getDouble("nota"));
            Aluno a = new Aluno();
            a.setIdAluno(rs.getInt("idAluno"));
            n.setAluno(a);
            Disciplina d = new Disciplina();
            d.setIdDisciplina(rs.getInt("idDisciplina"));
            n.setDisciplina(d);
            Professor p = new Professor();
            p.setIdProfessor(rs.getInt("idProfessor"));
            n.setProfessor(p);
            lista.add(n);
        }
        this.desconectar();
        return lista;
    }
    
    public ArrayList<NotasDisc> getListaNotasAluno(int idAluno) throws Exception{
        
        ArrayList<NotasDisc> lista = new ArrayList<NotasDisc>();
        String SQL = "SELECT n.idNotas, n.nota, a.idAluno, a.nome AS nomeAluno, d.idDisciplina, d.nome AS nomeDisciplina, "
                   + "p.idProfessor, p.nome AS nomeProfessor, c.idCurso, c.nome AS nomeCurso, nc.nota AS mediaFinal, t.nome AS nomeTurma FROM notasdisc n " +
                     "INNER JOIN aluno a ON n.idAluno = a.idAluno " +
                     "INNER JOIN disciplina d ON n.idDisciplina = d.idDisciplina " +
                     "INNER JOIN professor p ON n.idProfessor = p.idProfessor " +
                     "INNER JOIN curso c ON c.idCurso = d.idCurso " +
                     "INNER JOIN notascurso nc ON nc.idCurso = c.idCurso " +
                     "INNER JOIN turma t ON t.idCurso = c.idCurso " +
                     "INNER JOIN matricula m ON t.idTurma  = m.idTurma " +
                     "WHERE n.idAluno = ?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(SQL);
        pstm.setInt(1, idAluno);
        ResultSet rs = pstm.executeQuery();
        while(rs.next()){
            NotasDisc n = new NotasDisc();
            n.setIdNotas(rs.getInt("idNotas"));
            n.setNota(rs.getDouble("nota"));
            Aluno a = new Aluno();
            a.setIdAluno(rs.getInt("idAluno"));
            a.setNome(rs.getString("nomeAluno"));
            n.setAluno(a);
            Disciplina d = new Disciplina();
            d.setIdDisciplina(rs.getInt("idDisciplina"));
            d.setNome(rs.getString("nomeDisciplina"));
            Curso c = new Curso();
            c.setNome(rs.getString("nomeCurso"));
            c.setIdCurso(rs.getInt("idCurso"));
            d.setCurso(c);
            n.setDisciplina(d);
            Professor p = new Professor();
            p.setIdProfessor(rs.getInt("idProfessor"));
            p.setNome(rs.getString("nomeProfessor"));
            n.setProfessor(p);
            double mediaFinal = rs.getDouble("mediaFinal");
            n.setMediaFinal(mediaFinal);
            String nomeTurma = rs.getString("nomeTurma");
            n.setNomeTurma(nomeTurma);
            lista.add(n);
        }
        this.desconectar();
        return lista;
    }
    
    public NotasDisc getCarregaNotasID(int idNotas) throws Exception{
        
        NotasDisc n = new NotasDisc();
        String sql = "SELECT * FROM notasdisc WHERE idNotas = ?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idNotas);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            n.setIdNotas(rs.getInt("idNotas"));
            n.setNota(rs.getDouble("nota"));
            Aluno a = new Aluno();
            a.setIdAluno(rs.getInt("idAluno"));
            n.setAluno(a);
            Disciplina d = new Disciplina();
            d.setIdDisciplina(rs.getInt("idDisciplina"));
            n.setDisciplina(d); 
            Professor p = new Professor();
            p.setIdProfessor(rs.getInt("idProfessor"));
            n.setProfessor(p);
        }
        this.desconectar();
        return n;
    }
    
    public boolean alterarNotas(NotasDisc n){
        
        try{
            this.conectar();
            String sql = "UPDATE notasdisc SET nota = ?, idAluno = ?, idDisciplina = ?, idProfessor = ? WHERE idNotas = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setDouble(1, n.getNota());
            pstm.setInt(2, n.getAluno().getIdAluno());
            pstm.setInt(3, n.getDisciplina().getIdDisciplina());
            pstm.setInt(4, n.getProfessor().getIdProfessor());
            pstm.setInt(5, n.getIdNotas());
            int linhasAfetadas = pstm.executeUpdate();
            this.desconectar();
            if(linhasAfetadas > 0){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public void somarNotas(int idAluno, double mediaNota) throws Exception{
        
        try{
            this.conectar();
            String sql = "SELECT nota FROM notasdisc WHERE idAluno = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idAluno);
            ResultSet rs = pstm.executeQuery();
            double notaExistente = 0.0;
            if(rs.next()){
                notaExistente = rs.getDouble("nota");
            }
            double novaNotaTotal = notaExistente + mediaNota;
            String sqlUp = "UPDATE notasdisc SET nota = ? WHERE idAluno = ?";
            PreparedStatement pstmUp = conn.prepareStatement(sqlUp);
            pstmUp.setDouble(1, novaNotaTotal);
            pstmUp.setInt(2, idAluno);
            pstmUp.executeUpdate();
            this.desconectar(); 
        }catch(Exception e){
            System.out.println(e);
            
        }
    }
    
    public List<NotasDisc> getListaNotas2(int idProfessor) throws Exception {
    List<NotasDisc> notas = new ArrayList<>();
    try {
        this.conectar();
        String sql = "SELECT nd.idNotas, nd.nota, a.nome AS nomeAluno, d.idDisciplina, d.nome AS nomeDisciplina, c.idCurso, c.nome AS nomeCurso, t.nome AS nomeTurma "
                   + "FROM notasdisc nd "
                   + "INNER JOIN aluno a ON nd.idAluno = a.idAluno "
                   + "INNER JOIN disciplina d ON d.idDisciplina = nd.idDisciplina "
                   + "INNER JOIN curso c ON c.idCurso = d.idCurso "
                   + "INNER JOIN turma t ON t.idCurso = c.idCurso "
                   + "INNER JOIN matricula m ON m.idTurma = t.idTurma "
                   + "WHERE nd.idProfessor = ?";
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idProfessor);
        ResultSet rs = pstm.executeQuery();
        while (rs.next()) {
            NotasDisc nd = new NotasDisc();
            nd.setIdNotas(rs.getInt("idNotas"));
            nd.setNota(rs.getDouble("nota"));
            
            Aluno a = new Aluno();
            a.setNome(rs.getString("nomeAluno"));
            nd.setAluno(a);
            
            Disciplina d = new Disciplina();
            d.setIdDisciplina(rs.getInt("idDisciplina"));
            d.setNome(rs.getString("nomeDisciplina"));
            
            Curso c = new Curso();
            c.setIdCurso(rs.getInt("idCurso"));
            c.setNome(rs.getString("nomeCurso"));
            
            d.setCurso(c);
            nd.setDisciplina(d);
            String nomeTurma = rs.getString("nomeTurma");
            nd.setNomeTurma(nomeTurma);
            notas.add(nd);
        }
        this.desconectar();
        }catch (Exception e) {
            System.out.println(e);
        }
    return notas;
    }
}
