
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class NotasCursoDAO extends DatabaseDAO{
        
    public NotasCursoDAO() throws Exception{}
    
    public boolean gravarNotaFinal(int idAluno, int idCurso) {
        
    try {
        this.conectar();
        String sqlVerificaIdNotasCurso = "SELECT idNotas FROM notascurso WHERE idAluno = ? AND idCurso = ?";
        PreparedStatement pstmVerifica = conn.prepareStatement(sqlVerificaIdNotasCurso);
        pstmVerifica.setInt(1, idAluno);
        pstmVerifica.setInt(2, idCurso);
        ResultSet rsVerifica = pstmVerifica.executeQuery();
        if (rsVerifica.next()) {
            int idNotas = rsVerifica.getInt("idNotas");
            String sqlSomaNotas = "SELECT SUM(nota) AS soma_notas FROM notasdisc WHERE idAluno = ? AND idDisciplina IN (SELECT idDisciplina FROM disciplina WHERE idCurso = ?)";
            PreparedStatement pstmSoma = conn.prepareStatement(sqlSomaNotas);
            pstmSoma.setInt(1, idAluno);
            pstmSoma.setInt(2, idCurso);
            ResultSet rsSoma = pstmSoma.executeQuery();
            double somaNotas = 0;
            if (rsSoma.next()) {
                somaNotas = rsSoma.getDouble("soma_notas");
            }
            String sqlUpdate = "UPDATE notascurso SET nota = ? WHERE idNotas = ?";
            PreparedStatement pstmUpdate = conn.prepareStatement(sqlUpdate);
            pstmUpdate.setDouble(1, somaNotas);
            pstmUpdate.setInt(2, idNotas);
            pstmUpdate.executeUpdate();
        } else {
            String sqlSomaNotas = "SELECT SUM(nota) AS soma_notas FROM notasdisc WHERE idAluno = ? AND idDisciplina IN (SELECT idDisciplina FROM disciplina WHERE idCurso = ?)";
            PreparedStatement pstmSoma = conn.prepareStatement(sqlSomaNotas);
            pstmSoma.setInt(1, idAluno);
            pstmSoma.setInt(2, idCurso);
            ResultSet rsSoma = pstmSoma.executeQuery();
            double somaNotas = 0;
            if (rsSoma.next()) {
                somaNotas = rsSoma.getDouble("soma_notas");
            }
            String sqlInsert = "INSERT INTO notascurso (nota, idAluno, idCurso) VALUES (?, ?, ?)";
            PreparedStatement pstmInsert = conn.prepareStatement(sqlInsert);
            pstmInsert.setDouble(1, somaNotas);
            pstmInsert.setInt(2, idAluno);
            pstmInsert.setInt(3, idCurso);
            pstmInsert.executeUpdate();
        }
            this.desconectar();
            return true;
        }catch(Exception e) {
            System.out.println(e);
            return false;
        }
    }
    
    public NotasCurso getNotaCurso(int idCurso, int idAluno) throws Exception{
    
        NotasCurso nc = new NotasCurso();
        try {
        this.conectar();
        String sql = "SELECT nota FROM notascurso WHERE idCurso = ? AND idAluno = ?";
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idCurso);
        pstm.setInt(2, idAluno);
        ResultSet rs = pstm.executeQuery();
        while(rs.next()){
            nc.setNota(rs.getDouble("nota"));
        }
        this.desconectar();
        }catch(Exception e) {
            System.out.println(e);
        }
        return nc;
    }
}

