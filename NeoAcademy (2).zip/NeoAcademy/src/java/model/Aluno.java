
package model;

public class Aluno extends Usuario{
    private int idAluno;

    public int getIdAluno() {
        return idAluno;
    }

    public void setIdAluno(int idAluno) {
        this.idAluno = idAluno;
    }
    
    @Override
    public String toString() {
        return "Aluno{" + "idAluno=" + idAluno + ", nome=" + getNome() + ", email=" + getEmail() + ","
                + "cpf=" + getCpf() + ", telefone=" + getTelefone() + ", data_nasc=" + getData_nasc() + ","
                + "genero=" + getGenero() + ", cep=" + getCep() + ", logradouro=" + getLogradouro() + ","
                + "bairro=" + getBairro() + ", cidade=" + getCidade() + ", uf=" + getUf() + ", usuario=" + getUsuario() + ","
                + "senha=" + getSenha() + ", numero=" + getNumero() + ", imagem=" + imagem + ", status=" + status + '}';        
    }            
}
