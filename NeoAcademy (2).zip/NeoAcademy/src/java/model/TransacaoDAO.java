
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class TransacaoDAO extends DatabaseDAO{
    
    public TransacaoDAO() throws Exception{}
    
    public boolean gravarTransacao(Transacao t){
        
        try{
            this.conectar();
            String sql = "INSERT INTO transacao (data, valor, numero, idAluno, idCurso)"
                    + "VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, t.getData());
            pstm.setDouble(2, t.getValor());
            pstm.setString(3, t.getNumero());
            pstm.setInt(4, t.getAluno().getIdAluno());
            pstm.setInt(5, t.getCurso().getIdCurso());
            pstm.executeUpdate();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public ArrayList<Transacao> getListaTransacoes(int idAluno) throws Exception{
        
        ArrayList<Transacao> lista = new ArrayList<>();
        String SQL = "SELECT t.numero, t.data, t.valor, a.nome AS nomeAluno, cr.idCurso, cr.nome AS nomeCurso "
                + "FROM transacao t "
                + "INNER JOIN aluno a ON a.idAluno = t.idAluno "
                + "INNER JOIN curso cr ON cr.idCurso = t.idCurso "
                + "WHERE t.idAluno = ?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(SQL);
        pstm.setInt(1, idAluno);
        ResultSet rs = pstm.executeQuery();
        while(rs.next()){
            Aluno a = new Aluno();
            a.setNome(rs.getString("nomeAluno"));
            Curso cr = new Curso();
            cr.setIdCurso(rs.getInt("idCurso"));
            cr.setNome(rs.getString("nomeCurso"));
            Transacao t = new Transacao();
            t.setData(rs.getString("data"));
            t.setValor(rs.getDouble("valor"));
            t.setNumero(rs.getString("numero"));
            t.setAluno(a);
            t.setCurso(cr);
            lista.add(t);
        }
        this.desconectar();
        return lista;
    }
}
