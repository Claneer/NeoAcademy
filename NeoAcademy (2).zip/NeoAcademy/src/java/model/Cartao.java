
package model;

public class Cartao {
    
    private int idCartao;
    private String numero;
    private String vencimento;
    private String titular;
    private int cvv;
    private Aluno aluno;
    private int status;

    public int getIdCartao() {
        return idCartao;
    }

    public void setIdCartao(int idCartao) {
        this.idCartao = idCartao;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getVencimento() {
        return vencimento;
    }

    public void setVencimento(String vencimento) {
        this.vencimento = vencimento;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public int getCvv() {
        return cvv;
    }

    public void setCvv(int cvv) {
        this.cvv = cvv;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Cartao{" + "idCartao=" + idCartao + ", numero=" + numero + ", "
                + "vencimento=" + vencimento + ", titular=" + titular + ", cvv=" + cvv + ", aluno=" + aluno + ", "
                + "status=" + status + '}';
    }
}
