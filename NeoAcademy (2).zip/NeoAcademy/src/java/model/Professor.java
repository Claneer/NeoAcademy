
package model;

public class Professor extends Usuario{
    private int idProfessor;
    private double salario;
    private Administrador administrador;

    public int getIdProfessor() {
        return idProfessor;
    }

    public void setIdProfessor(int idProfessor) {
        this.idProfessor = idProfessor;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    public Administrador getAdministrador() {
        return administrador;
    }

    public void setAdministrador(Administrador administrador) {
        this.administrador = administrador;
    }

    @Override
    public String toString() {
        return "Professor{" + "idProfessor=" + idProfessor + ", nome=" + getNome() + ", email=" + getEmail() + ","
                + "cpf=" + getCpf() + ", telefone=" + getTelefone() + ", data_nasc=" + getData_nasc() + ","
                + "genero=" + getGenero() + ", cep=" + getCep() + ", logradouro=" + getLogradouro() + ","
                + "bairro=" + getBairro() + ", cidade=" + getCidade() + ", uf=" + getUf() + ", usuario=" + getUsuario() + ","
                + "senha=" + getSenha() + ", numero=" + getNumero() + ", salario=" + salario + ", administrador=" + administrador + ", "
                + "imagem=" + imagem + ", status=" + status + '}';
    }    
}
