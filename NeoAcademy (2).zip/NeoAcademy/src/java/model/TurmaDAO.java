
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TurmaDAO extends DatabaseDAO{
    
    public TurmaDAO() throws Exception{}
    
    public boolean gravarTurma(Turma t){
        
        try{
            this.conectar();
            String sql = "INSERT INTO turma (nome, vagas, idCurso, idAdmin)"
                    + "VALUES (?, ?, ?, ?)";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, t.getNome());
            pstm.setInt(2, t.getNumeroVagas());
            pstm.setInt(3, t.getCurso().getIdCurso());
            pstm.setInt(4, t.getAdministrador().getIdAdmin());
            pstm.executeUpdate();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public ArrayList<Turma> getListaTurma() throws Exception{
        
        ArrayList<Turma> lista = new ArrayList<Turma>();
        String sql = "SELECT * FROM turma";
        this.conectar();
        Statement stm = conn.createStatement();
        ResultSet rs = stm.executeQuery(sql);
        while(rs.next()){
            Turma t = new Turma();
            t.setIdTurma(rs.getInt("idTurma"));
            t.setNome(rs.getString("nome"));
            t.setNumeroVagas(rs.getInt("vagas"));
            Curso c = new Curso();
            c.setIdCurso(rs.getInt("idCurso"));
            t.setCurso(c);
            lista.add(t);
        }this.desconectar();
        return lista;
    }
        
    public Turma getCarregaTurmaID(int idTurma) throws Exception{
        
        Turma t = new Turma();
        String sql = "SELECT * FROM turma WHERE idTurma = ?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idTurma);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            t.setIdTurma(rs.getInt("idTurma"));
            t.setNome(rs.getString("nome"));
            t.setNumeroVagas(rs.getInt("vagas"));
        }
        this.desconectar();
        return t;
    }
    
    public boolean alterarTurma(Turma t){
        
        try{
            this.conectar();
            String sql = "UPDATE turma SET nome = ?, vagas = ? WHERE idTurma = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, t.getNome());
            pstm.setInt(2, t.getNumeroVagas());
            pstm.setInt(3, t.getIdTurma());
            int linhasAfetadas = pstm.executeUpdate();
            this.desconectar();
            if(linhasAfetadas > 0){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public boolean Deletar(Turma t){
        
        try{
            this.conectar();
            String sql = "DELETE FROM turma WHERE idTurma = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, t.getIdTurma());
            pstm.execute();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public Turma getNomeIdTurmaFK(int idAluno)throws Exception{
    
        Turma t = new Turma();
        try{
            this.conectar();
            String sql = "SELECT t.idTurma, t.idCurso, t.nome AS nomeTurma FROM aluno a "
                + "INNER JOIN matricula m ON m.idAluno = a.idAluno "
                + "INNER JOIN turma t ON t.idTurma = m.idTurma "
                + "WHERE a.idAluno = ?";
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idAluno);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            t.setIdTurma(rs.getInt("idTurma"));
            t.setNome(rs.getString("nomeTurma"));
            Curso c = new Curso();
            c.setIdCurso(rs.getInt("idCurso"));
            t.setCurso(c);
        }
        this.desconectar();
        }catch(Exception e){
            System.out.println(e);
            
        }
        return t;
    }
    
    public List<Turma> getListaDeTurmas(int idCurso) throws Exception{
        
        List<Turma> turmas = new ArrayList<>();
        try{
            this.conectar();
            String sql = "SELECT idTurma, vagas FROM turma WHERE idCurso = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idCurso);
            ResultSet rs = pstm.executeQuery();
            while(rs.next()){
                Turma t = new Turma();
                t.setIdTurma(rs.getInt("idTurma"));
                t.setNumeroVagas(rs.getInt("vagas"));
                turmas.add(t);   
            }
            this.desconectar();
        }catch(Exception e){
            System.out.println(e);
        }
        return turmas;
    }
    
    public int virificarTurmaDisponivel(int idCurso)throws Exception{
    
        int contador = 0;
        try{
            this.conectar();
            String sql = "SELECT * FROM turma WHERE idCurso = ?";
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idCurso);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            contador = rs.getInt(1);
        }
        this.desconectar();
        }catch(Exception e){
            System.out.println(e);
            
        }
        return contador;
    }
}
