
package model;

public class Curso {
    
    private int idCurso;
    private String nome;
    private int cargaHoraria;
    private String descricao;
    private double valor;
    private Transacao transacao;
    private Administrador administrador;

    public int getIdCurso() {
        return idCurso;
    }

    public void setIdCurso(int idCurso) {
        this.idCurso = idCurso;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(int cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public Transacao getTransacao() {
        return transacao;
    }

    public void setTransacao(Transacao transacao) {
        this.transacao = transacao;
    }

    public Administrador getAdministrador() {
        return administrador;
    }

    public void setAdministrador(Administrador administrador) {
        this.administrador = administrador;
    }

    @Override
    public String toString() {
        return "Curso{" + "idCurso=" + idCurso + ", nome=" + nome + ", cargaHoraria=" + cargaHoraria + ", "
                + "descricao=" + descricao + ", valor=" + valor + ", transacao=" + transacao + ", "
                + "administrador=" + administrador + '}';
    }   
}
