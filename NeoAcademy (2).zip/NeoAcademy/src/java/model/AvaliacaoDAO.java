
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AvaliacaoDAO extends DatabaseDAO{
    
    public AvaliacaoDAO() throws Exception{}
    
    public boolean gravarAvaliacao (Avaliacao av){
        
        try{
            this.conectar();
            String sql = "INSERT INTO avaliacao (questao, alterA, alterB, alterC, alterD, alterE, alterCerta, valor, idProfessor, idDisciplina)"
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, av.getQuestao());
            pstm.setString(2, av.getAlterA());
            pstm.setString(3, av.getAlterB());
            pstm.setString(4, av.getAlterC());
            pstm.setString(5, av.getAlterD());
            pstm.setString(6, av.getAlterE());
            pstm.setString(7, av.getAlterCerta());
            pstm.setDouble(8, av.getValor());
            pstm.setInt(9, av.getProfessor().getIdProfessor());
            pstm.setInt(10, av.getDisciplina().getIdDisciplina());
            pstm.executeUpdate();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public ArrayList<Avaliacao> getListaAvaliacao() throws Exception{
        
        ArrayList<Avaliacao> lista = new ArrayList<Avaliacao>();
        String SQL = "SELECT * FROM avaliacao";
        this.conectar();
        Statement stm = conn.createStatement();
        ResultSet rs = stm.executeQuery(SQL);
        while(rs.next()){
            Avaliacao av = new Avaliacao();
            av.setIdAvaliacao(rs.getInt("idAvaliacao"));
            av.setQuestao(rs.getString("questao"));
            av.setAlterA(rs.getString("alterA"));
            av.setAlterB(rs.getString("alterB"));
            av.setAlterC(rs.getString("alterC"));
            av.setAlterD(rs.getString("alterD"));
            av.setAlterE(rs.getString("alterE"));
            av.setAlterCerta(rs.getString("alterCerta"));
            av.setValor(rs.getDouble("valor"));
            Professor p = new Professor();
            p.setIdProfessor(rs.getInt("idProfessor"));
            Disciplina d = new Disciplina();
            d.setIdDisciplina(rs.getInt("idDisciplina"));
            av.setProfessor(p);
            lista.add(av);
        }
        this.desconectar();
        return lista;
    }
    
    public ArrayList<Avaliacao> getListaAvaliacao(int idProfessor) throws Exception{
        
    ArrayList<Avaliacao> lista = new ArrayList<Avaliacao>();
    String SQL = "SELECT * FROM avaliacao WHERE idProfessor = ?";
    this.conectar();
    PreparedStatement pstm = conn.prepareStatement(SQL);
    pstm.setInt(1, idProfessor);
    ResultSet rs = pstm.executeQuery();
    while(rs.next()){
        Avaliacao av = new Avaliacao();
        av.setIdAvaliacao(rs.getInt("idAvaliacao"));
        av.setQuestao(rs.getString("questao"));
        av.setAlterA(rs.getString("alterA"));
        av.setAlterB(rs.getString("alterB"));
        av.setAlterC(rs.getString("alterC"));
        av.setAlterD(rs.getString("alterD"));
        av.setAlterE(rs.getString("alterE"));
        av.setAlterCerta(rs.getString("alterCerta"));
        av.setValor(rs.getDouble("valor"));
        Professor p = new Professor();
        p.setIdProfessor(rs.getInt("idProfessor"));
        av.setProfessor(p);
        Disciplina d = new Disciplina();
        d.setIdDisciplina(rs.getInt("idDisciplina"));
        av.setDisciplina(d);
        lista.add(av);
    }
        this.desconectar();
        return lista;
    }
    
    public ArrayList<Avaliacao> getListaAvaliacao(int idProfessor, int idDisciplina) throws Exception{
        
    ArrayList<Avaliacao> lista = new ArrayList<Avaliacao>();
    String SQL = "SELECT * FROM avaliacao WHERE idProfessor = ? AND idDisciplina = ?";
    this.conectar();
    PreparedStatement pstm = conn.prepareStatement(SQL);
    pstm.setInt(1, idProfessor);
    pstm.setInt(2, idDisciplina);
    ResultSet rs = pstm.executeQuery();
    while(rs.next()){
        Avaliacao av = new Avaliacao();
        av.setIdAvaliacao(rs.getInt("idAvaliacao"));
        av.setQuestao(rs.getString("questao"));
        av.setAlterA(rs.getString("alterA"));
        av.setAlterB(rs.getString("alterB"));
        av.setAlterC(rs.getString("alterC"));
        av.setAlterD(rs.getString("alterD"));
        av.setAlterE(rs.getString("alterE"));
        av.setAlterCerta(rs.getString("alterCerta"));
        av.setValor(rs.getDouble("valor"));
        Professor p = new Professor();
        p.setIdProfessor(rs.getInt("idProfessor"));
        Disciplina d = new Disciplina();
        d.setIdDisciplina(rs.getInt("idDisciplina"));
        av.setProfessor(p);
        lista.add(av);
    }
        this.desconectar();
        return lista;
    }
    
    public ArrayList<Integer> getListaIdAvaliacao() throws Exception {
        ArrayList<Integer> listaIds = new ArrayList<>();
        String SQL = "SELECT idAvaliacao FROM avaliacao";
        this.conectar();
        Statement stm = conn.createStatement();
        ResultSet rs = stm.executeQuery(SQL);
        while (rs.next()) {
        listaIds.add(rs.getInt("idAvaliacao"));
        }
        this.desconectar();
        return listaIds;
    }
    
    public boolean AlterarAvaliacao(Avaliacao av){
        
        try{
            this.conectar();
            String sql = "UPDATE avaliacao SET questao =? , alterA = ?, alterB = ?, alterC = ?, alterD = ?, alterE"
                    + " = ?, alterCerta = ?, valor = ?"
                    + "WHERE idAvaliacao = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, av.getQuestao());
            pstm.setString(2, av.getAlterA());
            pstm.setString(3, av.getAlterB());
            pstm.setString(4, av.getAlterC());
            pstm.setString(5, av.getAlterD());
            pstm.setString(6, av.getAlterE());
            pstm.setString(7, av.getAlterCerta());
            pstm.setDouble(8, av.getValor());
            pstm.setInt(9, av.getIdAvaliacao());
            int linhasAfetadas = pstm.executeUpdate();
            this.desconectar();
            if(linhasAfetadas > 0){
                return true;
            }else{
                return false;
            }
        }catch(Exception ex){
            System.out.println(ex);
            return false;
        }
    }
    
    public Avaliacao getCarregaAvaliacaoID(int idAvaliacao) throws Exception{
        
        Avaliacao av = new Avaliacao();
        String sql = "SELECT * FROM avaliacao WHERE idAvaliacao = ?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idAvaliacao);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            av.setIdAvaliacao(rs.getInt("idAvaliacao"));
            av.setQuestao(rs.getString("questao"));
            av.setAlterA(rs.getString("alterA"));
            av.setAlterB(rs.getString("alterB"));
            av.setAlterC(rs.getString("alterC"));
            av.setAlterD(rs.getString("alterD"));
            av.setAlterE(rs.getString("alterE"));
            av.setAlterCerta(rs.getString("alterCerta"));
            av.setValor(rs.getDouble("valor"));
        }
        this.desconectar();
        return av;
    }
    
    public boolean Deletar(Avaliacao av){
        
        try{
            this.conectar();
            String sql = "DELETE FROM avaliacao WHERE idAvaliacao = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, av.getIdAvaliacao());
            pstm.execute();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public List<Avaliacao> getListaAvaliacao2(int idProfessor) throws Exception {
    List<Avaliacao> avaliacoes = new ArrayList<>();
    try {
        this.conectar();
        String sql = "SELECT a.idAvaliacao, a.questao, a.alterA, a.alterB, a.alterC, a.alterD, a.alterE, a.alterCerta, a.valor, d.idDisciplina, d.nome AS nomeDisciplina, c.idCurso, c.nome AS nomeCurso "
                   + "FROM avaliacao a "
                   + "INNER JOIN disciplina d ON a.idDisciplina = d.idDisciplina "
                   + "INNER JOIN curso c ON d.idCurso = c.idCurso "
                   + "WHERE a.idProfessor = ?";
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idProfessor);
        ResultSet rs = pstm.executeQuery();
        while (rs.next()) {
            Avaliacao av = new Avaliacao();
            av.setIdAvaliacao(rs.getInt("idAvaliacao"));
            av.setQuestao(rs.getString("questao"));
            av.setAlterA(rs.getString("alterA"));
            av.setAlterB(rs.getString("alterB"));
            av.setAlterC(rs.getString("alterC"));
            av.setAlterD(rs.getString("alterD"));
            av.setAlterE(rs.getString("alterE"));
            av.setAlterCerta(rs.getString("alterCerta"));
            av.setValor(rs.getFloat("valor"));
            
            Disciplina d = new Disciplina();
            d.setIdDisciplina(rs.getInt("idDisciplina"));
            d.setNome(rs.getString("nomeDisciplina"));
            
            Curso c = new Curso();
            c.setIdCurso(rs.getInt("idCurso"));
            c.setNome(rs.getString("nomeCurso"));
            
            d.setCurso(c);
            av.setDisciplina(d);

            avaliacoes.add(av);
        }
        this.desconectar();
        }catch (Exception e) {
            System.out.println(e);
        }
    return avaliacoes;
    }
}
