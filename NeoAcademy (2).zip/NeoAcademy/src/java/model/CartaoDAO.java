
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class CartaoDAO extends DatabaseDAO{
    
    public CartaoDAO() throws Exception{}
    
    public boolean gravarCartao(Cartao c, String numero){
        
        try{
            this.conectar();
            
            String verificaSql = "SELECT COUNT(*) FROM cartao WHERE numero = ?";
            PreparedStatement verificaPstm = conn.prepareStatement(verificaSql);
            verificaPstm.setString(1, c.getNumero());
            ResultSet rs = verificaPstm.executeQuery();
            rs.next();
            int count = rs.getInt(1);
            if (count > 0) {
            return true;
            }else{
            String sql = "INSERT INTO cartao (numero, vencimento, titular, cvv, idAluno)"
                    + "VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, c.getNumero());
            pstm.setString(2, c.getVencimento());
            pstm.setString(3, c.getTitular());
            pstm.setInt(4, c.getCvv());
            pstm.setInt(5, c.getAluno().getIdAluno());
            pstm.executeUpdate();
            }
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }

    }
    
    public ArrayList<Cartao> getListaCartao(int idAluno) throws Exception{
        
        ArrayList<Cartao> lista = new ArrayList<>();
        String sql = "SELECT * FROM cartao WHERE idAluno = ?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idAluno);
        ResultSet rs = pstm.executeQuery();
        while(rs.next()){
            Cartao c = new Cartao();
            c.setIdCartao(rs.getInt("idCartao"));
            c.setNumero(rs.getString("numero"));
            c.setVencimento(rs.getString("vencimento"));
            c.setTitular(rs.getString("titular"));
            c.setCvv(rs.getInt("cvv"));
            lista.add(c);
        }
        this.desconectar();
        return lista;
    }
    
    public ArrayList<Cartao> getListaCartoes(int idAluno) throws Exception{
        
        ArrayList<Cartao> lista = new ArrayList<>();
        String SQL = "SELECT a.nome AS nomeAluno, c.idCartao, c.numero, c.vencimento, c.titular, c.cvv, c.status FROM cartao c "
                + "INNER JOIN aluno a ON a.idAluno = c.idAluno "
                + "WHERE c.idAluno = ?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(SQL);
        pstm.setInt(1, idAluno);
        ResultSet rs = pstm.executeQuery();
        while(rs.next()){
            Aluno a = new Aluno();
            a.setNome(rs.getString("nomeAluno"));
            Cartao c = new Cartao();
            c.setIdCartao(rs.getInt("idCartao"));
            c.setNumero(rs.getString("numero"));
            c.setVencimento(rs.getString("vencimento"));
            c.setTitular(rs.getString("titular"));
            c.setCvv(rs.getInt("cvv"));
            c.setStatus(rs.getInt("status"));
            c.setAluno(a);
            lista.add(c);
        }
        this.desconectar();
        return lista;
    }

    
    public Cartao getCarregaCartaoID(int idCartao) throws Exception{
        
        Cartao ca = new Cartao();
        String sql = "SELECT * FROM cartao WHERE idCartao = ?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idCartao);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            ca.setIdCartao(rs.getInt("idCartao"));
            ca.setNumero(rs.getString("numero"));
            ca.setVencimento(rs.getString("vencimento"));
            ca.setTitular(rs.getString("titular"));
            ca.setCvv(rs.getInt("cvv"));    
        }
        this.desconectar();
        return ca;
    }
    
    public Cartao getIdCartao(String numero){
        
        Cartao c = new Cartao();
        try{
            this.conectar();
            String sql = "SELECT * FROM cartao WHERE numero = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, numero);
            ResultSet rs = pstm.executeQuery();
            if(rs.next()){
                c.setIdCartao(rs.getInt("idCartao"));
            }
            this.desconectar();
        }catch(Exception e){
            System.out.println(e);
        }
        return c;
    }
    
    public boolean Ativar(int idCartao){
         
         try{
            this.conectar();
            String sql = "UPDATE cartao SET status = 1 WHERE idCartao = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idCartao);
            int linhasAfetadas = pstm.executeUpdate();
            this.desconectar();
            if(linhasAfetadas > 0){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
     }
     
     public boolean Desativar(int idCartao){
         
         try{
            this.conectar();
            String sql = "UPDATE cartao SET status = 0 WHERE idCartao = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idCartao);
            int linhasAfetadas = pstm.executeUpdate();
            this.desconectar();
            if(linhasAfetadas > 0){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
     }
     
     public boolean Deletar(Cartao c){
        
        try{
            this.conectar();
            String sql = "DELETE FROM cartao WHERE idCartao = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, c.getIdCartao());
            pstm.execute();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
     
     public int verificaCartao(String numero){
         
         int contador = 0;
         try{
            this.conectar();
            String sql = "SELECT COUNT(*) FROM cartao WHERE numero = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, numero);
            ResultSet rs = pstm.executeQuery();
            if(rs.next()){
               contador = rs.getInt(1);
            }
            this.desconectar();
        }catch(Exception e){
            System.out.println(e);
        }
         return contador;
     }
     
     public int verificaStatusCartao(String numero){
     
         int status = -1;
         try{
            this.conectar();
            String sql = "SELECT status FROM cartao WHERE numero = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, numero);
            ResultSet rs = pstm.executeQuery();
            if(rs.next()){
               status = rs.getInt("status");
            }
            this.desconectar();
        }catch(Exception e){
            System.out.println(e);
        }
         return status;
     }
    
    public boolean isValidLuhn(String numero){
            int nDigits = numero.length();
            int sum = 0;
            boolean isSecond = false;
            for (int i = nDigits - 1; i >= 0; i--) {
                int d = numero.charAt(i) - '0';
                if (isSecond)
                    d = d * 2;
                sum += d / 10;
                sum += d % 10;
                isSecond = !isSecond;
            }
            return (sum % 10 == 0);
        }
}
