
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class DisciplinaDAO extends DatabaseDAO{
    
    public DisciplinaDAO() throws Exception{}
    
    public boolean gravarDisciplina(Disciplina d){
        
        try{
            this.conectar();
            String sql = "INSERT INTO disciplina (nome, cargaHoraria, idProfessor, idCurso, idAdmin)"
                    + "VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, d.getNome());
            pstm.setInt(2, d.getCargaHoraria());
            pstm.setInt(3, d.getProfessor().getIdProfessor());
            pstm.setInt(4, d.getCurso().getIdCurso());
            pstm.setInt(5, d.getAdministrador().getIdAdmin());
            pstm.executeUpdate();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public ArrayList<Disciplina> getListaDisciplina () throws Exception{
        
        ArrayList<Disciplina> lista = new ArrayList<Disciplina>();
        String sql = "SELECT * FROM disciplina";
        this.conectar();
        Statement stm = conn.createStatement();
        ResultSet rs = stm.executeQuery(sql);
        while(rs.next()){
            Disciplina d = new Disciplina();
            d.setNome(rs.getString("nome"));
            d.setIdDisciplina(rs.getInt("idDisciplina"));
            d.setCargaHoraria(rs.getInt("cargaHoraria"));
            Professor p = new Professor();
            p.setIdProfessor(rs.getInt("idProfessor"));
            d.setProfessor(p);
            Curso c = new Curso();
            c.setIdCurso(rs.getInt("idCurso"));
            d.setCurso(c);
            lista.add(d);            
        }this.desconectar();
        return lista;   
    }
    
    public ArrayList<Disciplina> getListaIdNomeDisciplina(int idProfessor) throws Exception {
        
        ArrayList<Disciplina> lista = new ArrayList<>();
        String SQL = "SELECT idDisciplina, nome FROM disciplina WHERE idProfessor = ?";
        try {
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(SQL);
        pstm.setInt(1, idProfessor);
        ResultSet rs = pstm.executeQuery();
        while (rs.next()) {
            Disciplina d = new Disciplina();
            d.setIdDisciplina(rs.getInt("idDisciplina"));
            d.setNome(rs.getString("nome"));
            lista.add(d);
        }
        }catch (Exception e) {
        System.out.println(e);;
        }
        this.desconectar();
        return lista;
    }
    
    public ArrayList<Disciplina> getListaIdNomeDisciplinaCurso(int idCurso) throws Exception {
        
        ArrayList<Disciplina> lista = new ArrayList<>();
        String SQL = "SELECT idDisciplina, nome, idProfessor FROM disciplina WHERE idCurso = ?";
        try {
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(SQL);
        pstm.setInt(1, idCurso);
        ResultSet rs = pstm.executeQuery();
        while (rs.next()) {
            Disciplina d = new Disciplina();
            d.setIdDisciplina(rs.getInt("idDisciplina"));
            d.setNome(rs.getString("nome"));
            Professor p = new Professor();
            p.setIdProfessor(rs.getInt("idProfessor"));
            d.setProfessor(p);
            lista.add(d);
        }
        }catch (Exception e) {
        System.out.println(e);;
        }
        this.desconectar();
        return lista;
    }
    
    public Disciplina getCarregaDisciplinaID(int idDisciplina) throws Exception{
        
        Disciplina d = new Disciplina();
        String sql = "SELECT * FROM disciplina WHERE idDisciplina = ?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idDisciplina);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            d.setIdDisciplina(rs.getInt("idDisciplina"));
            d.setNome(rs.getString("nome"));
            d.setCargaHoraria(rs.getInt("cargaHoraria"));
            d.setNota(rs.getDouble("nota"));
            Professor p = new Professor();
            p.setIdProfessor(rs.getInt("idProfessor"));
            d.setProfessor(p);
            Curso c = new Curso();
            c.setIdCurso(rs.getInt("idCurso"));
            d.setCurso(c);
        }
        this.desconectar();
        return d;
    }
    
    public boolean alterarDisciplina(Disciplina d){
        
        try{
            this.conectar();
            String sql = "UPDATE disciplina SET nome = ?, cargaHoraria = ?, idProfessor = ?, idCurso = ? "
                    + "WHERE idDisciplina = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, d.getNome());
            pstm.setInt(2, d.getCargaHoraria());
            pstm.setInt(3, d.getProfessor().getIdProfessor());
            pstm.setInt(4, d.getCurso().getIdCurso());
            pstm.setInt(5, d.getIdDisciplina());
            int linhasAfetadas = pstm.executeUpdate();
            this.desconectar();
            if(linhasAfetadas > 0){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public boolean Deletar(Disciplina d){
        
        try{
            this.conectar();
            String sql = "DELETE FROM disciplina WHERE idDisciplina = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, d.getIdDisciplina());
            pstm.execute();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public int contaDisciplina(int idCurso) throws Exception{
        
        int numeroDisciplinas = 0;
        try{
            this.conectar();
            String sql = "SELECT COUNT(idDisciplina) AS numDisciplina "
                    + "FROM disciplina WHERE idCurso = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idCurso);
            ResultSet rs = pstm.executeQuery();
            if(rs.next()){
                numeroDisciplinas = rs.getInt("numDisciplina");
            }
            this.desconectar();
        }catch(Exception e){
            System.out.println(e);
            
        }
        return numeroDisciplinas;
    }
    
    public int getFkCursoDisciplina(int idDisciplina){
        
        int idCurso = -1;
        try{
            this.conectar();
            String sql = "SELECT idCurso FROM disciplina WHERE idDisciplina = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idDisciplina);
            ResultSet rs = pstm.executeQuery();
            if(rs.next()){
                idCurso = rs.getInt("idCurso");
            }
            this.desconectar();
        }catch(Exception e){
            System.out.println(e);
            
        }
        return idCurso;
    }
    
    public Disciplina getNomeDisciplina(int idProfessor) throws Exception{
       
       Disciplina d = new Disciplina();
       try{
           this.conectar();
           String sql = "SELECT d.idDisciplina, d.nome AS nomeDisciplina, c.idCurso, c.nome AS nomeCurso "
                   + "FROM disciplina d "
                   + "INNER JOIN professor p ON p.idProfessor = d.idProfessor "
                   + "INNER JOIN curso c ON c.idCurso = d.idCurso "
                   + "WHERE d.idProfessor = ?";
           PreparedStatement pstm = conn.prepareStatement(sql);
           pstm.setInt(1, idProfessor);
           ResultSet rs = pstm.executeQuery();
           if(rs.next()){
               d.setIdDisciplina(rs.getInt("idDisciplina"));
               d.setNome(rs.getString("nomeDisciplina"));
               Curso c = new Curso();
               c.setIdCurso(rs.getInt("idCurso"));
               c.setNome(rs.getString("nomeCurso"));
               d.setCurso(c);
               this.desconectar();
           }
       }catch(Exception e){
           System.out.println(e);
       }
       return d;
   }
}
