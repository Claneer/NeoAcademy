
package model;

public class Avaliacao {
    
    private int idAvaliacao;
    private String questao;
    private String alterA;
    private String alterB;
    private String alterC;
    private String alterD;
    private String alterE;
    private String alterCerta;
    private double valor;
    private Professor professor;
    private Disciplina disciplina;

    public int getIdAvaliacao() {
        return idAvaliacao;
    }

    public void setIdAvaliacao(int idAvaliacao) {
        this.idAvaliacao = idAvaliacao;
    }

    public String getQuestao() {
        return questao;
    }

    public void setQuestao(String questao) {
        this.questao = questao;
    }

    public String getAlterA() {
        return alterA;
    }

    public void setAlterA(String alterA) {
        this.alterA = alterA;
    }

    public String getAlterB() {
        return alterB;
    }

    public void setAlterB(String alterB) {
        this.alterB = alterB;
    }

    public String getAlterC() {
        return alterC;
    }

    public void setAlterC(String alterC) {
        this.alterC = alterC;
    }

    public String getAlterD() {
        return alterD;
    }

    public void setAlterD(String alterD) {
        this.alterD = alterD;
    }

    public String getAlterE() {
        return alterE;
    }

    public void setAlterE(String alterE) {
        this.alterE = alterE;
    }

    public String getAlterCerta() {
        return alterCerta;
    }

    public void setAlterCerta(String alterCerta) {
        this.alterCerta = alterCerta;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }
    
    public Disciplina getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }

    @Override
    public String toString() {
        return "Avaliacao{" + "idAvaliacao=" + idAvaliacao + ", questao=" + 
                questao + ", alterA=" + alterA + ", alterB=" + alterB + ", alterC=" + 
                alterC + ", alterD=" + alterD + ", alterE=" + alterE + ", alterCerta=" + 
                alterCerta + ", valor=" + valor + ", professor=" + professor + ", disciplina=" + disciplina + '}';
    }    
}
