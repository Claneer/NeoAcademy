
package model;

public class NotasCurso {
    
    private int idNotas;
    private double nota;
    private Aluno aluno;
    private Curso curso;

    public int getIdNotas() {
        return idNotas;
    }

    public void setIdNotas(int idNotas) {
        this.idNotas = idNotas;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    @Override
    public String toString() {
        return "NotasCurso{" + "idNotas=" + idNotas + ", nota=" + nota + ", aluno=" + aluno + ", curso=" + curso + '}';
    }
}
