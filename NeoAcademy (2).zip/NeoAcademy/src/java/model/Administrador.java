
package model;

public class Administrador extends Usuario{
    private int idAdmin;
    private double salario;

    public int getIdAdmin() {
        return idAdmin;
    }

    public void setIdAdmin(int idAdmin) {
        this.idAdmin = idAdmin;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    @Override
    public String toString() {
        return "Administrador{" + "idAdmin=" + idAdmin + ", nome=" + getNome() + ", email=" + getEmail() + ","
                + "cpf=" + getCpf() + ", telefone=" + getTelefone() + ", data_nasc=" + getData_nasc() + ","
                + "genero=" + getGenero() + ", cep=" + getCep() + ", logradouro=" + getLogradouro() + ","
                + "bairro=" + getBairro() + ", cidade=" + getCidade() + ", uf=" + getUf() + ", usuario=" + getUsuario() + ","
                + "senha=" + getSenha() + ", numero=" + getNumero() + ", salario=" + salario + ", imagem=" + imagem + ", "
                + "status=" + status + '}';
    }  
}
