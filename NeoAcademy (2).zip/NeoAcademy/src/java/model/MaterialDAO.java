
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class MaterialDAO extends DatabaseDAO{
    
    public MaterialDAO() throws Exception{}
    
    public boolean gravarMaterial (Material m){
        
        try{
            this.conectar();
            String sql = "INSERT INTO material (nome, tipo, orientacao, url, idDisciplina, idProfessor)"
                    + "VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, m.getNome());
            pstm.setString(2, m.getTipo());
            pstm.setString(3, m.getOrientacao());
            pstm.setString(4, m.getUrl());
            pstm.setInt(5, m.getDisciplina().getIdDisciplina());
            pstm.setInt(6, m.getProfessor().getIdProfessor());
            pstm.executeUpdate();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public ArrayList<Material> getListaMaterial(int idProfessor) throws Exception{
        
        ArrayList<Material> lista = new ArrayList<Material>();
        String sql = "SELECT * FROM material WHERE idProfessor = ?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idProfessor);
        ResultSet rs = pstm.executeQuery();
        while(rs.next()){
            Material m = new Material();
            m.setIdMaterial(rs.getInt("idMaterial"));
            m.setNome(rs.getString("nome"));
            m.setTipo(rs.getString("tipo"));
            m.setOrientacao(rs.getString("orientacao"));
            m.setUrl(rs.getString("url"));
            Disciplina d = new Disciplina();
            d.setIdDisciplina(rs.getInt("idDisciplina"));
            m.setDisciplina(d);
            Professor p = new Professor();
            p.setIdProfessor(rs.getInt("idProfessor"));
            m.setProfessor(p);
            lista.add(m);            
        }this.desconectar();
        return lista;   
    }
    
    public Material getCarregaMaterialID(int idMaterial) throws Exception{
        
        Material m = new Material();
        String sql = "SELECT * FROM material WHERE idMaterial = ?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idMaterial);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            m.setIdMaterial(rs.getInt("idMaterial"));
            m.setNome(rs.getString("nome"));
            m.setTipo(rs.getString("tipo"));
            m.setOrientacao(rs.getString("orientacao"));
            m.setUrl(rs.getString("url"));
            Disciplina d = new Disciplina();
            d.setIdDisciplina(rs.getInt("idDisciplina"));
            m.setDisciplina(d);
            Professor p = new Professor();
            p.setIdProfessor(rs.getInt("idProfessor"));
            m.setProfessor(p);
        }
        this.desconectar();
        return m;
    }
    
    public boolean alterarMaterial(Material m){
        
        try{
            this.conectar();
            String sql = "UPDATE material SET nome = ?, tipo = ?, orientacao = ?, url = ?, idDisciplina = ? WHERE idMaterial = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, m.getNome());
            pstm.setString(2, m.getTipo());
            pstm.setString(3, m.getOrientacao());
            pstm.setString(4, m.getUrl());
            pstm.setInt(5, m.getDisciplina().getIdDisciplina());
            pstm.setInt(6, m.getIdMaterial());
            int linhasAfetadas = pstm.executeUpdate();
            this.desconectar();
            if(linhasAfetadas > 0){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public boolean Deletar(Material m){
        
        try{
            this.conectar();
            String sql = "DELETE FROM material WHERE idMaterial = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, m.getIdMaterial());
            pstm.execute();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public ArrayList<Material> getListaMaterialDisciplina(int idDisciplina, int idProfessor) throws Exception{
        
        ArrayList<Material> lista = new ArrayList<Material>();
        String sql = "SELECT * FROM material WHERE idDisciplina = ? AND idProfessor = ?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idDisciplina);
        pstm.setInt(2, idProfessor);
        ResultSet rs = pstm.executeQuery();
        while(rs.next()){
            Material m = new Material();
            m.setNome(rs.getString("nome"));
            m.setTipo(rs.getString("tipo"));
            m.setOrientacao(rs.getString("orientacao"));
            m.setUrl(rs.getString("url"));
            lista.add(m);            
        }this.desconectar();
        return lista;   
    }
    
    public List<Material> getListaMaterial2(int idProfessor) throws Exception {
    List<Material> conteudo = new ArrayList<>();
    try {
        this.conectar();
        String sql = "SELECT m.idMaterial, m.nome AS nomeMaterial, m.tipo, m.orientacao, m.url, d.idDisciplina, d.nome AS nomeDisciplina, c.idCurso, c.nome AS nomeCurso "
                   + "FROM material m "
                   + "INNER JOIN disciplina d ON m.idDisciplina = d.idDisciplina "
                   + "INNER JOIN curso c ON d.idCurso = c.idCurso "
                   + "WHERE m.idProfessor = ?";
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idProfessor);
        ResultSet rs = pstm.executeQuery();
        while (rs.next()) {
            Material m = new Material();
            m.setIdMaterial(rs.getInt("idMaterial"));
            m.setNome(rs.getString("nomeMaterial"));
            m.setTipo(rs.getString("tipo"));
            m.setOrientacao(rs.getString("orientacao"));
            m.setUrl(rs.getString("url"));
            
            Disciplina d = new Disciplina();
            d.setIdDisciplina(rs.getInt("idDisciplina"));
            d.setNome(rs.getString("nomeDisciplina"));
            
            Curso c = new Curso();
            c.setIdCurso(rs.getInt("idCurso"));
            c.setNome(rs.getString("nomeCurso"));
            
            d.setCurso(c);
            m.setDisciplina(d);

            conteudo.add(m);
        }
        this.desconectar();
        }catch (Exception e) {
            System.out.println(e);
        }
    return conteudo;
    }
}
