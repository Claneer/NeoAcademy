
package model;

public class Transacao {
    
    private int idTransacao;
    private String data;
    private double valor;
    private String numero;        
    private Aluno aluno;
    private Curso curso;

    public int getIdTransacao() {
        return idTransacao;
    }

    public void setIdTransacao(int idTransacao) {
        this.idTransacao = idTransacao;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    @Override
    public String toString() {
        return "Transacao{" + "idTransacao=" + idTransacao + ", data=" + data + ", "
                + "valor=" + valor + ", numero=" + numero + ", aluno=" + aluno + ", curso=" + curso + '}';
    }
 
}
