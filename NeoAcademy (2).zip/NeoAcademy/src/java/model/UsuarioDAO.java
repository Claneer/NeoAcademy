
package model;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class UsuarioDAO extends DatabaseDAO{
   
    public UsuarioDAO() throws Exception{}
        
    public boolean recuperarEmail (Usuario u){
        try{
            this.conectar();
            String sql = "SELECT COUNT(*) AS total FROM aluno WHERE email = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, u.getEmail());
            ResultSet resultado = pstm.executeQuery();
            int total = 0;
            if(resultado.next()){
                total = resultado.getInt("total");
            }
            this.desconectar();
            return total>0;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
     public boolean recuperarNasc (Usuario u){
        try{
            this.conectar();
            String sql = "SELECT COUNT(*) AS total FROM aluno WHERE email = ? AND data_nasc = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, u.getEmail());
            pstm.setString(2, u.getData_nasc());
            ResultSet resultado = pstm.executeQuery();
            int total = 0;
            if(resultado.next()){
                total = resultado.getInt("total");
            }
            this.desconectar();
            return total>0;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
     
     public boolean recuperarCpf (Usuario u){
         try{
             this.conectar();
             String sql = "SELECT COUNT(*) AS total FROM aluno WHERE email = ? AND data_nasc = ? AND RIGHT(cpf, 3) = ?";
             PreparedStatement pstm = conn.prepareStatement(sql);
             pstm.setString(1, u.getEmail());
             pstm.setString(2, u.getData_nasc());
             pstm.setString(3, u.getCpf());
             ResultSet resultado = pstm.executeQuery();
             int total = 0;
             if(resultado.next()){
                 total = resultado.getInt("total");
             }
             this.desconectar();
             return total>0;
         }catch(Exception e){
             System.out.println(e);
             return false;
         }
     }
      
     public boolean recuperarSenha(Usuario u){
         
         try{
             this.conectar();
             String sql = "UPDATE aluno SET senha = ? WHERE email = ? AND data_nasc = ? AND RIGHT(cpf, 3) = ?";
             PreparedStatement pstm = conn.prepareStatement(sql);
             pstm.setString(1, u.getSenha());
             pstm.setString(2, u.getEmail());
             pstm.setString(3, u.getData_nasc());
             pstm.setString(4, u.getCpf());
             int linhasAfetadas = pstm.executeUpdate();
             this.desconectar();
             if(linhasAfetadas > 0){
                 return true;
             }else{
                 return false;
             }
         }catch(Exception e){
             System.out.println(e);
             return false;
         }
     }
     
     public Usuario getRecuperarUsuario(String usuario){
         
         Usuario u = new Usuario();
         String sql = "SELECT u.* FROM aluno u WHERE u.usuario = ?";
         
         try{
             this.conectar();
             PreparedStatement pstm = conn.prepareStatement(sql);
             pstm.setString(1, usuario);
             ResultSet resultado = pstm.executeQuery();
             if(resultado.next()){
                 u.setNome(resultado.getString("u.nome"));
                 u.setEmail(resultado.getString("u.email"));
                 u.setCpf(resultado.getString("u.cpf"));
                 u.setEmail(resultado.getString("u.telefone"));
                 u.setData_nasc(resultado.getString("u.data_nasc"));
                 u.setGenero(resultado.getString("genero"));
                 u.setCep(resultado.getString("u.cep"));
                 u.setLogradouro(resultado.getString("u.logradouro"));
                 u.setBairro(resultado.getString("u.bairro"));
                 u.setCidade(resultado.getString("u.cidade"));
                 u.setUf(resultado.getString("u.uf"));
                 u.setNumero(resultado.getInt("u.numero"));
                 u.setUsuario(resultado.getString("u.usuario"));
                 u.setSenha(resultado.getString("u.senha"));
             }
             this.desconectar();
             return u;
         }catch(Exception e){
             System.out.println(e);
             return null;
         }
         
     }
     
     public boolean isValidLuhn(String number){
            int nDigits = number.length();
            int sum = 0;
            boolean isSecond = false;
            for (int i = nDigits - 1; i >= 0; i--) {
                int d = number.charAt(i) - '0';
                if (isSecond)
                    d = d * 2;
                sum += d / 10;
                sum += d % 10;
                isSecond = !isSecond;
            }
            return (sum % 10 == 0);
        }
     
    public boolean validaCPF(String cpf) {
        if (cpf == null || cpf.length() != 11 || cpf.matches("(\\d)\\1{10}")) {
            return false;
        }

        try {
            int sum = 0;
            for (int i = 0; i < 9; i++) {
                sum += (cpf.charAt(i) - '0') * (10 - i);
            }
            int digit1 = 11 - (sum % 11);
            if (digit1 >= 10) digit1 = 0;

            sum = 0;
            for (int i = 0; i < 9; i++) {
                sum += (cpf.charAt(i) - '0') * (11 - i);
            }
            sum += digit1 * 2;
            int digit2 = 11 - (sum % 11);
            if (digit2 >= 10) digit2 = 0;

            return cpf.charAt(9) - '0' == digit1 && cpf.charAt(10) - '0' == digit2;
        } catch (Exception e) {
            return false;
        }
    }
    
    public String hashSenhaMD5(String senha) {
        try {
            // Cria uma instância do MessageDigest com o algoritmo MD5
            MessageDigest md = MessageDigest.getInstance("MD5");

            // Converte a string de entrada para bytes e computa o hash
            byte[] messageDigest = md.digest(senha.getBytes());

            // Converte o array de bytes para uma representação hexadecimal
            StringBuilder hexString = new StringBuilder();
            for (byte b : messageDigest) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
}
   
