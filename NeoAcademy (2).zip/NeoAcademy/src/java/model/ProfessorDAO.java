
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class ProfessorDAO extends DatabaseDAO{
    
    public ProfessorDAO() throws Exception{}
        
    public boolean gravarProfessor (Professor p){
        try{
            this.conectar();
            String sql = "INSERT INTO professor (nome, email, cpf, telefone, data_nasc, genero, cep, logradouro, bairro, "
                    + "cidade, uf, numero, usuario, senha, salario, idAdmin) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, p.getNome());
            pstm.setString(2, p.getEmail());
            pstm.setString(3, p.getCpf());
            pstm.setString(4, p.getTelefone());
            pstm.setString(5, p.getData_nasc());
            pstm.setString(6, p.getGenero());
            pstm.setString(7, p.getCep());
            pstm.setString(8, p.getLogradouro());
            pstm.setString(9, p.getBairro());
            pstm.setString(10, p.getCidade());
            pstm.setString(11, p.getUf());
            pstm.setInt(12, p.getNumero());
            pstm.setString(13, p.getUsuario());
            pstm.setString(14, p.getSenha());
            pstm.setDouble(15, p.getSalario());
            pstm.setInt(16, p.getAdministrador().getIdAdmin());
            pstm.executeUpdate();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public ArrayList<Professor> getListaProfessor() throws Exception{
        
        ArrayList<Professor> lista = new ArrayList<Professor>();
        String SQL = "SELECT * FROM professor";
        this.conectar();
        Statement stm = conn.createStatement();
        ResultSet rs = stm.executeQuery(SQL);
        while(rs.next()){
            Professor p = new Professor();
            p.setIdProfessor(rs.getInt("idProfessor"));
            p.setNome(rs.getString("nome"));
            p.setEmail(rs.getString("email"));
            p.setTelefone(rs.getString("telefone"));
            p.setUsuario(rs.getString("usuario"));
            p.setStatus(rs.getInt("status"));
            lista.add(p);
        }
        this.desconectar();
        return lista;
    }
    
    public Professor getCarregaProfessorID(int idProfessor) throws Exception{
        
        Professor p = new Professor();
        String sql = "SELECT * FROM professor WHERE idProfessor = ?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idProfessor);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            p.setIdProfessor(rs.getInt("idProfessor"));
            p.setNome(rs.getString("nome"));
            p.setEmail(rs.getString("email"));
            p.setCpf(rs.getString("cpf"));
            p.setTelefone(rs.getString("telefone"));
            p.setData_nasc(rs.getString("data_nasc"));
            p.setCep(rs.getString("cep"));
            p.setLogradouro(rs.getString("logradouro"));
            p.setBairro(rs.getString("bairro"));
            p.setCidade(rs.getString("cidade"));
            p.setUf(rs.getString("uf"));
            p.setNumero(rs.getInt("numero"));
            p.setUsuario(rs.getString("usuario"));
            p.setSenha(rs.getString("senha"));
            p.setSalario(rs.getDouble("salario"));
            byte[] imagemBytes = rs.getBytes("foto");
            p.setImagem(imagemBytes);
        }
        this.desconectar();
        return p;
    }
    
    public boolean alterarProfessor(Professor p){
        
        try{
            this.conectar();
            String sql = "UPDATE professor SET nome = ?, email = ?, cpf = ?, telefone = ?, data_nasc = ?,"
                    + " genero = ?, cep = ?, logradouro = ?, bairro = ?, cidade = ?, uf = ?, "
                    + "numero = ?, usuario = ?, senha = ?, salario = ?, foto = ? WHERE idProfessor = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1,p.getNome());
            pstm.setString(2,p.getEmail());
            pstm.setString(3,p.getCpf());
            pstm.setString(4,p.getTelefone());
            pstm.setString(5,p.getData_nasc());
            pstm.setString(6,p.getGenero());
            pstm.setString(7,p.getCep());
            pstm.setString(8,p.getLogradouro());
            pstm.setString(9,p.getBairro());
            pstm.setString(10,p.getCidade());
            pstm.setString(11,p.getUf());
            pstm.setInt(12,p.getNumero());
            pstm.setString(13,p.getUsuario());
            pstm.setString(14,p.getSenha());
            pstm.setDouble(15,p.getSalario());
            pstm.setBytes(16, p.getImagem());
            pstm.setInt(17, p.getIdProfessor());
            int linhasAfetadas = pstm.executeUpdate();
            this.desconectar();
            if(linhasAfetadas > 0){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public boolean Deletar(Professor p){
        
        try{
            this.conectar();
            String sql = "DELETE FROM professor WHERE idProfessor = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, p.getIdProfessor());
            pstm.execute();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public Professor getLoginProf(String usuario){
         
         Professor p = new Professor();
         String sql = "SELECT p.* FROM professor p WHERE p.usuario = ?";
         
         try{
             this.conectar();
             PreparedStatement pstm = conn.prepareStatement(sql);
             pstm.setString(1, usuario);
             ResultSet resultado = pstm.executeQuery();
             if(resultado.next()){
                 p.setIdProfessor(resultado.getInt("p.idProfessor"));
                 p.setNome(resultado.getString("p.nome"));
                 p.setUsuario(resultado.getString("p.usuario"));
                 p.setSenha(resultado.getString("p.senha"));
                 p.setStatus(resultado.getInt("p.status"));
             }
             this.desconectar();
             return p;
         }catch(Exception e){
             System.out.println(e);
             return null;
         }
         
     }
    
    public ArrayList<Professor> getListaIdNomeProfessor() throws Exception {
        
        ArrayList<Professor> lista = new ArrayList<>();
        String SQL = "SELECT idProfessor, nome FROM professor";
        try {
        this.conectar();
        Statement stm = conn.createStatement();
        ResultSet rs = stm.executeQuery(SQL);
        while (rs.next()) {
            Professor p = new Professor();
            p.setIdProfessor(rs.getInt("idProfessor"));
            p.setNome(rs.getString("nome"));
            lista.add(p);
        }
        }catch (Exception e) {
        System.out.println(e);;
        }
        this.desconectar();
        return lista;
    }
    
    public Professor pegarEmailNomeProfessor(int idProfessor) throws Exception {
        
        Professor p = new Professor();
        try {
        this.conectar();
        String sql = "SELECT email, nome FROM professor WHERE idProfessor = ?";
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idProfessor);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            p.setEmail(rs.getString("email"));
            p.setNome(rs.getString("nome"));
        }
        this.desconectar();
        return p;
        }catch (Exception e) {
            System.out.println(e);;
            return null;
        }
    }
    
    public boolean Ativar(int idProfessor){
         
         try{
            this.conectar();
            String sql = "UPDATE professor SET status = 1 WHERE idProfessor = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idProfessor);
            int linhasAfetadas = pstm.executeUpdate();
            this.desconectar();
            if(linhasAfetadas > 0){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
     }
     
     public boolean Desativar(int idProfessor){
         
         try{
            this.conectar();
            String sql = "UPDATE professor SET status = 0 WHERE idProfessor = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idProfessor);
            int linhasAfetadas = pstm.executeUpdate();
            this.desconectar();
            if(linhasAfetadas > 0){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
     }
}
