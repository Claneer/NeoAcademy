
package model;

public class NotasDisc {
    
    private int idNotas;
    private double nota;
    private Aluno aluno;
    private Disciplina disciplina;
    private Professor professor;
    private double mediaFinal;
    private String nomeTurma;

    public int getIdNotas() {
        return idNotas;
    }

    public void setIdNotas(int idNotas) {
        this.idNotas = idNotas;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public double getMediaFinal() {
        return mediaFinal;
    }

    public void setMediaFinal(double mediaFinal) {
        this.mediaFinal = mediaFinal;
    }

    public String getNomeTurma() {
        return nomeTurma;
    }

    public void setNomeTurma(String nomeTurma) {
        this.nomeTurma = nomeTurma;
    }

    @Override
    public String toString() {
        return "NotasDisc{" + "idNotas=" + idNotas + ", nota=" + nota + ", aluno=" + aluno + ", "
                + "disciplina=" + disciplina + ", professor=" + professor + ", mediaFinal=" + mediaFinal + ", "
                + "nomeTurma=" + nomeTurma + '}';
    }

}
    
