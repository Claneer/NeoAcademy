
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MatriculaDAO extends DatabaseDAO{
    
    public MatriculaDAO() throws Exception{}
       
   public ArrayList<Map<String, String>> getListaNomeMatricula(int idAluno) throws Exception {
        
        ArrayList<Map<String, String>> lista = new ArrayList<>();
        String SQL = "SELECT DISTINCT c.nome AS nomeCurso, c.idCurso AS idCurso, t.nome AS nomeTurma " +
                     "FROM Matricula m " +
                     "JOIN Turma t ON m.idTurma = t.idTurma " +
                     "JOIN Curso c ON t.idCurso = c.idCurso " +
                     "WHERE m.idAluno = ?";
        try {
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(SQL);
        pstm.setInt(1, idAluno);
        ResultSet rs = pstm.executeQuery();
        while (rs.next()) {
            Map<String, String> matricula = new HashMap<>();
            matricula.put("nomeCurso", rs.getString("nomeCurso"));
            matricula.put("idCurso", rs.getString("idCurso"));
            matricula.put("nomeTurma", rs.getString("nomeTurma"));
            lista.add(matricula);
        }
        }catch (Exception e) {
                System.out.println(e);
        }
        this.desconectar();
            return lista;
    }
   
   public int contarMatriculas(int idTurma){
    int count = 0;
    try{
        this.conectar();
        String sql = "SELECT COUNT(*) FROM matricula WHERE idTurma = ?";
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idTurma);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            count = rs.getInt(1);
        }
        this.desconectar();
    }catch(Exception e){
        System.out.println(e);
    }
    return count;
    }

   
   public boolean gravarMatricula(Matricula m){
        
        try{
            this.conectar();
            String sql = "INSERT INTO matricula (idAluno, idTurma)"
                    + "VALUES (?, ?)";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, m.getAluno().getIdAluno());
            pstm.setInt(2, m.getTurma().getIdTurma());
            pstm.executeUpdate();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
   
   public int checarMatricula(int idAluno, int idCurso){
       
       int contador = 0;
        try{
            this.conectar();
            String sql = "SELECT * FROM matricula m "
                    + "INNER JOIN turma t ON t.idTurma = m.idTurma "
                    + "INNER JOIN aluno a ON a.idAluno = m.idAluno "
                    + "WHERE m.idAluno = ? AND t.idCurso = ? ";
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idAluno);
        pstm.setInt(2, idCurso);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            contador = rs.getInt(1);
        }
        this.desconectar();
        }catch(Exception e){
            System.out.println(e);
            
        }
        return contador;
   }
}
